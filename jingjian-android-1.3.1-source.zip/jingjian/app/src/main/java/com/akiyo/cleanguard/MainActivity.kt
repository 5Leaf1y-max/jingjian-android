package com.akiyo.cleanguard

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

private const val TARGET_PACKAGE = "com.mobiletools.systemhelper"
private const val REQUEST_CODE = 1001
private const val PREFS_NAME = "jingjian_local"
private const val PREF_LAST_REPORT = "last_detection_report"
private const val APP_VERSION = "1.3.0"
private const val PROJECT_URL = "https://github.com/5Leaf1y-max/jingjian-android"
private const val SHIZUKU_URL = "https://shizuku.rikka.app/"

class MainActivity : ComponentActivity() {
    private val permissionGranted = mutableStateOf(false)
    private val binderAvailable = mutableStateOf(false)
    private val requestListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) permissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val deadListener = Shizuku.OnBinderDeadListener {
        binderAvailable.value = false
        permissionGranted.value = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(requestListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refreshShizuku()
        setContent { JingJianApp(binderAvailable.value, permissionGranted.value, onGrant = { requestShizuku() }) }
    }

    override fun onResume() {
        super.onResume()
        refreshShizuku()
    }

    private fun refreshShizuku() {
        val available = try { Shizuku.pingBinder() && !Shizuku.isPreV11() } catch (_: Exception) { false }
        binderAvailable.value = available
        permissionGranted.value = available && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                binderAvailable.value = false
                permissionGranted.value = false
                Toast.makeText(this, "请先启动 Shizuku 服务", Toast.LENGTH_LONG).show()
                return
            }
            binderAvailable.value = true
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                permissionGranted.value = true
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (_: Exception) {
            permissionGranted.value = false
            Toast.makeText(this, "无法检查 Shizuku 状态，请确认 Shizuku 正常运行", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(requestListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { HOME("首页"), CHECK("检测"), ACTION("操作"), ABOUT("关于") }

@Composable
private fun JingJianApp(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember(context) { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var report by remember(prefs) { mutableStateOf(prefs.getString(PREF_LAST_REPORT, "尚未检测") ?: "尚未检测") }
    var command by remember { mutableStateOf("pm list packages -u --user 0 | grep -F $TARGET_PACKAGE") }
    var commandOutput by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPrivacyInfo by remember { mutableStateOf(false) }
    val activity = context as ComponentActivity
    val executor = remember { Executors.newSingleThreadExecutor() }
    val shell = remember(context) { ShizukuShellClient(context.applicationContext) }
    var showFreeNotice by remember { mutableStateOf(true) }

    DisposableEffect(shell, executor) {
        onDispose {
            shell.close()
            executor.shutdownNow()
        }
    }

    fun runAsync(action: () -> String, onResult: (String) -> Unit) {
        if (busy) return
        busy = true
        executor.execute {
            val result = try { action() } catch (e: Exception) { "操作失败：${e.message ?: e.javaClass.simpleName}" }
            activity.runOnUiThread { onResult(result); busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF356BCE), background = Color(0xFFF5F7FB), surface = Color.White)) {
        Scaffold(
            containerColor = Color(0xFFF5F7FB),
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when (item) {
                                    Tab.HOME -> Icons.Default.Home
                                    Tab.CHECK -> Icons.Default.FactCheck
                                    Tab.ACTION -> Icons.Default.Build
                                    Tab.ABOUT -> Icons.Default.Info
                                }, contentDescription = item.label)
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("净鉴", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Android 系统组件检测与管理 · $APP_VERSION", color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (tab) {
                    Tab.HOME -> {
                        ShizukuStatusCard(shizukuGranted, binderAvailable)
                        ShizukuGuide(binderAvailable, shizukuGranted, onGrant)
                        HomeHeroCard()
                        Text("设备信息", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        InfoCard("净鉴版本", APP_VERSION, Color(0xFFEAF1FF))
                        InfoCard("设备型号", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", Color(0xFFEAF7EF))
                        InfoCard("Android 版本", "Android ${android.os.Build.VERSION.RELEASE}（API ${android.os.Build.VERSION.SDK_INT}）", Color(0xFFFFF3E5))
                        InfoCard("系统指纹", android.os.Build.FINGERPRINT, Color(0xFFF1ECFF))
                        InfoCard("什么是 System Helper？", """System Helper 是中国联通的设备管理客户端，属于运营商定制预装的遥测组件。部分 OPPO、vivo、小米等品牌的国行系统中可能预装此类组件。它通常位于系统特权分区，普通用户无法像普通应用一样直接卸载。根据部分设备的逆向分析，它可能涉及设备与 SIM 标识（如 IMEI、IMSI、ICCID）、已安装应用列表、应用使用情况、流量统计，以及部分基站、信号和定位相关信息。不同厂商、机型和系统版本的实际行为可能存在差异，以上不代表所有设备都会收集全部信息。

为什么建议卸载？如果当前用户空间仍安装并启用了该组件，它可能继续运行并访问相关数据。对于重视个人隐私、且不依赖相关厂商功能的用户，卸载当前用户中的组件可以减少它继续运行和访问数据的机会。卸载不会删除系统分区中的原始 APK，系统更新或恢复出厂设置后也可能重新安装；同时可能影响部分厂商功能，请结合自己的设备情况决定。""", Color(0xFFFFF0F0))
                    }
                    Tab.CHECK -> {
                        InfoCard("系统组件检测", "净鉴会检查System Helper在当前用户中的安装状态。如果检测到相关应用程序，净鉴出于保护隐私安全的考虑，建议您进行卸载操作。如果已经进行了卸载操作或者在当前系统版本未发现System Helper，它仍有可能在后续的系统更新中重新安装，建议您在系统更新后再次使用净鉴进行检测。当然，卸载操作的执行权完全归您所有，请在认真考虑后再执行操作。")
                        Button(enabled = shizukuGranted && !busy, onClick = { runAsync({ inspectTarget(shell) }) { report = it; prefs.edit().putString(PREF_LAST_REPORT, it).apply() } }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (busy) "检测中…" else "开始检测")
                        }
                        ResultCard(report)
                        if (report != "尚未检测") ExpandableDetails("查看原始检测结果", report)
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请返回首页，按照 Shizuku 授权引导完成服务启动和授权后，再开始检测。", Color(0xFFFFEEEE))
                    }
                    Tab.ACTION -> {
                        InfoCard("卸载组件", "如果你已经了解该组件的行为，并认为有必要停用它，可以考虑从当前用户空间卸载。此操作不会删除系统分区中的原始 APK，但可以让它在当前用户中停用。系统更新或恢复出厂设置后可能重新安装。卸载后可能影响厂商功能，请在权衡个人隐私与使用风险后操作。")
                        Button(enabled = shizukuGranted && !busy, onClick = { showConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("卸载组件") }
                        if (report != "尚未检测") ResultCard(report)
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请先在首页完成 Shizuku 服务启动和授权。", Color(0xFFFFEEEE))
                        ExpandableDetails("高级功能：手动 Shell 命令") {
                            Text("仅供了解 ADB / Shell 的用户使用。命令会以 Shizuku 当前授权身份执行，请确认内容安全。")
                            OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Shell 命令") }, minLines = 2)
                            Button(enabled = shizukuGranted && !busy && command.isNotBlank(), onClick = { runAsync({ shell.execute(command) }) { commandOutput = it } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "执行中…" else "执行命令") }
                            OutlinedButton(onClick = { copyText(context, command) }, modifier = Modifier.fillMaxWidth()) { Text("复制命令") }
                            if (commandOutput.isNotBlank()) {
                                Text("执行结果", fontWeight = FontWeight.SemiBold)
                                Text(commandOutput, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(onClick = { copyText(context, commandOutput) }, modifier = Modifier.fillMaxWidth()) { Text("复制结果") }
                            }
                        }
                    }
                    Tab.ABOUT -> {
                        InfoCard("简介", "净鉴是一款 Android 系统组件检测与管理工具，帮助用户了解和管理设备中的预装组件，降低潜在的隐私安全风险。本软件发布于2026年11月12日，完全公开免费，无盈利性质。")
                        InfoCard("作者", "5Leaf1y by ChatGPT")
                        TextButton(onClick = { showPrivacyInfo = true }) { Text("个人信息、权限收集和使用规范") }
                        TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问 GitHub 项目主页") }
                    }
                }
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认卸载组件？") },
            text = { Text("净鉴将尝试从当前用户（User 0）卸载 SystemHelper。不会删除系统分区中的原始 APK，但可能影响依赖它的厂商功能。系统更新或恢复出厂设置后也可能重新出现。确定继续吗？") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    runAsync({ performUninstall(shell) }) {
                        report = it
                        prefs.edit().putString(PREF_LAST_REPORT, it).apply()
                    }
                }) { Text("确认卸载") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("取消") } }
        )
    }

    if (showPrivacyInfo) {
        AlertDialog(
            onDismissRequest = { showPrivacyInfo = false },
            confirmButton = { TextButton(onClick = { showPrivacyInfo = false }) { Text("我知道了") } },
            title = { Text("个人信息、权限收集和使用规范") },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("一、权限说明", fontWeight = FontWeight.Bold)
                    Text("净鉴不会主动申请设备运行时权限，包括互联网、定位、电话号码、通讯录、相机、麦克风和悬浮窗等权限。应用清单中没有声明 INTERNET 权限，因此净鉴不会通过网络上传检测数据。Shizuku Provider 是用于连接 Shizuku 服务的组件，不是让净鉴绕过系统授权的通道；相关操作仍需要你在 Shizuku 中明确授权。")
                    Text("二、设备信息", fontWeight = FontWeight.Bold)
                    Text("净鉴会在本机读取设备型号、Android 版本和系统指纹，用于在首页展示设备信息。检测结果及最近一次检测记录保存在本机应用数据中，不会自动发送给开发者或其他服务器。")
                    Text("三、检测内容", fontWeight = FontWeight.Bold)
                    Text("获得 Shizuku 授权后，净鉴会检查 System Helper 在当前用户中的安装状态，并可能读取其包名、安装路径、权限声明、相关进程和系统命令返回的信息。这些信息用于生成检测结论。组件声明了某项权限，不代表它一定实际使用了该权限，也不能单凭权限列表认定其存在恶意行为。")
                    Text("四、卸载操作", fontWeight = FontWeight.Bold)
                    Text("只有在你主动点击卸载并确认后，净鉴才会尝试执行当前用户空间的卸载命令。该操作不会删除系统分区中的原始 APK，可能影响依赖该组件的厂商功能，系统更新或恢复出厂设置后也可能重新安装。是否卸载由你自行决定。")
                    Text("五、信息保存与撤销", fontWeight = FontWeight.Bold)
                    Text("净鉴不提供账号系统，不主动收集姓名、手机号、通讯录等个人资料，也不包含广告或统计 SDK。你可以在 Shizuku 中撤销净鉴的授权，或停止 Shizuku 服务。无线调试配对码由 Android 系统和 Shizuku 处理，净鉴不会读取、收集或保存配对码。卸载净鉴会清除系统为本应用保存的本地数据。")
                    Text("六、使用规范", fontWeight = FontWeight.Bold)
                    Text("请仅在自己拥有或已获得明确授权的设备上使用净鉴。执行卸载前，请了解可能产生的影响，并自行备份重要数据。检测结果仅供参考，设备厂商、型号和系统版本不同，检测结果与组件行为也可能不同。请遵守所在地法律法规，不得将本软件用于侵犯他人权益或破坏设备正常运行的行为。")
                }
            }
        )
    }

    if (showFreeNotice) {
        AlertDialog(
            onDismissRequest = { showFreeNotice = false },
            title = { Text("欢迎使用净鉴") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("免费使用 · 公开项目", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("净鉴是一款免费的 Android 系统组件检测与管理工具。")
                    Text("本应用免费提供，不收取使用费用；不含广告及付费解锁功能。项目代码与更新信息可通过 GitHub 查看。")
                    Text(PROJECT_URL, color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问项目主页") }
                }
            },
            confirmButton = {
                TextButton(onClick = { showFreeNotice = false }) { Text("开始使用") }
            }
        )
    }
}

@Composable
private fun ShizukuStatusCard(granted: Boolean, binderAvailable: Boolean) {
    val accent = if (granted) Color(0xFF209B62) else Color(0xFFD94343)
    val bg = if (granted) Color(0xFFE5F7EC) else Color(0xFFFFEAEA)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("Shizuku 授权状态", color = accent, fontWeight = FontWeight.Bold)
            Text(if (granted) "已授权 · 可以使用检测与卸载功能" else if (binderAvailable) "服务已启动 · 等待净鉴授权" else "尚未授权 · 暂不可使用检测与卸载", color = Color(0xFF202B36), fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(if (granted) "净鉴已获得 Shizuku 授权。你仍可在下方查看授权教程。" else "请先启动 Shizuku 服务，并按照下方引导完成授权。", color = Color(0xFF586574))
        }
    }
}

@Composable
private fun ShizukuGuide(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    var expanded by remember(shizukuGranted) { mutableStateOf(!shizukuGranted) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TextButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(0.dp)) {
                Text(if (expanded) "收起 Shizuku 授权教程" else "查看 Shizuku 授权教程", fontWeight = FontWeight.Bold)
            }
            if (expanded) {
                Text("净鉴需要通过 Shizuku 执行系统组件检测。授权由你主动确认，净鉴不会绕过 Android 系统授权。", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("1. 安装并打开 Shizuku。")
                OutlinedButton(onClick = { openShizuku(context) }, modifier = Modifier.fillMaxWidth()) { Text("打开 Shizuku") }
                TextButton(onClick = { openUrl(context, SHIZUKU_URL) }) { Text("查看 Shizuku 官方说明") }
                Text("2. 启动 Shizuku 服务。无 Root 设备通常使用无线调试；已 Root 设备可在 Shizuku 中选择 Root 启动方式。")
                Text("3. 无线调试方式：在 Android 开发者选项中开启无线调试，再回到 Shizuku 选择“通过无线调试启动”，按系统提示完成配对。配对码由系统和 Shizuku 处理，请勿发送给净鉴。")
                OutlinedButton(onClick = {
                    try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                    catch (_: Exception) { Toast.makeText(context, "请在系统设置中打开开发者选项", Toast.LENGTH_LONG).show() }
                }, modifier = Modifier.fillMaxWidth()) { Text("打开开发者选项") }
                Text("4. 在 Shizuku 中完成服务启动后，返回净鉴，点击下方按钮检查服务状态并授予净鉴权限。")
                Text("当前状态：${if (shizukuGranted) "净鉴已获得授权" else if (binderAvailable) "Shizuku 服务已连接，等待授权" else "Shizuku 服务尚未连接"}", color = if (shizukuGranted) Color(0xFF209B62) else Color(0xFFD94343))
                Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) { Text("检查状态并授权净鉴") }
            }
        }
    }
}

@Composable
private fun ResultCard(report: String, title: String = "检测结论") {
    val failed = report == "尚未检测" || summaryFor(report).startsWith("检测未能完成") || summaryFor(report).startsWith("卸载未能完成")
    val installed = report != "尚未检测" && isTargetInstalled(report)
    val accent = when {
        failed -> Color(0xFF64748B)
        installed -> Color(0xFFDC4545)
        else -> Color(0xFF229B62)
    }
    val container = when {
        failed -> Color(0xFFF1F4F8)
        installed -> Color(0xFFFFEEEE)
        else -> Color(0xFFEAF7EF)
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = accent)
            Text(if (report == "尚未检测") "尚未检测" else summaryFor(report), color = Color(0xFF263238))
        }
    }
}

@Composable
private fun StatusInfoCard(title: String, report: String) {
    val installed = isTargetInstalled(report)
    val failed = summaryFor(report).startsWith("检测未能完成")
    val accent = when { failed -> Color(0xFF64748B); installed -> Color(0xFFDC4545); else -> Color(0xFF229B62) }
    val container = when { failed -> Color(0xFFF1F4F8); installed -> Color(0xFFFFEEEE); else -> Color(0xFFEAF7EF) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = accent)
            Text(summaryFor(report), color = Color(0xFF263238))
        }
    }
}

@Composable
private fun HomeHeroCard() {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF1FF))) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("设备隐私概览", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2456A6))
            Text("关注预装系统组件的安装状态与数据访问行为", color = Color(0xFF49658F))
            Text("本地检测 · 自主授权 · 由你决定", fontSize = 12.sp, color = Color(0xFF60789D))
        }
    }
}

private fun isTargetInstalled(report: String): Boolean {
    val currentUserSection = report.substringAfter("=== 当前用户安装状态 ===", "")
        .substringBefore("=== 包记录（含已卸载记录） ===")
    return currentUserSection.contains("package:$TARGET_PACKAGE")
}

private fun summaryFor(report: String): String {
    if (report == "尚未检测") return report
    if (report.startsWith("已完成卸载！")) return "已完成卸载！"
    if (report.startsWith("没有找到System Helper，无需卸载哦！")) return "没有找到System Helper，无需卸载哦！"
    if (report.startsWith("卸载未能完成")) return report.substringBefore("\n")
    if (!report.contains("=== 当前用户安装状态 ===") || report.contains("Shizuku 服务未运行") || report.contains("尚未获得 Shizuku 授权") || report.contains("无法连接 Shizuku 服务") || report.contains("执行失败") || report.contains("执行超时") || report.contains("操作失败：")) {
        return "检测未能完成。请检查 Shizuku 服务和净鉴授权状态，然后重新检测。"
    }
    return if (isTargetInstalled(report)) {
        "当前用户空间发现System Helper，这可能导致您的用户数据被上传。"
    } else {
        "当前用户空间未发现System Helper，但系统分区中可能仍保留原始 APK（目前已无法运行，可以放心）。仍要注意的是，厂商系统更新或恢复出厂设置后可能重新安装。"
    }
}

@Composable
private fun ExpandableDetails(title: String, body: String) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(14.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ExpandableDetails(title: String, content: @Composable ColumnScope.() -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) content()
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, containerColor: Color = Color.White) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = containerColor), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Color(0xFF263445))
            Text(body, color = Color(0xFF596777))
        }
    }
}

private fun inspectTarget(shell: ShizukuShellClient): String {
    val script = """
        echo '=== 构建指纹 ==='
        getprop ro.build.fingerprint
        printf '\n=== 当前用户安装状态 ===\n'
        pm list packages --user 0 | grep -F '$TARGET_PACKAGE' || echo 'User 0 未安装'
        printf '\n=== 包记录（含已卸载记录） ===\n'
        pm list packages -u | grep -F '$TARGET_PACKAGE' || echo '未找到包记录'
        printf '\n=== APK 路径 ===\n'
        pm path '$TARGET_PACKAGE' || true
        printf '\n=== 权限声明与状态（节选） ===\n'
        dumpsys package '$TARGET_PACKAGE' | grep -E 'requested permissions:|install permissions:|runtime permissions:|android.permission.(ACCESS_FINE_LOCATION|ACCESS_COARSE_LOCATION|READ_PHONE_STATE|PACKAGE_USAGE_STATS|QUERY_ALL_PACKAGES|ACCESS_NETWORK_STATE|ACCESS_WIFI_STATE)' | head -n 80
        printf '\n=== 相关进程 ===\n'
        ps -A | grep -F '$TARGET_PACKAGE' || echo '未发现匹配进程'
    """.trimIndent()
    return shell.execute(script)
}

private fun performUninstall(shell: ShizukuShellClient): String {
    val before = shell.execute("pm list packages --user 0 | grep -F '$TARGET_PACKAGE' || true")
    if (!before.contains("package:$TARGET_PACKAGE")) {
        val verify = inspectTarget(shell)
        return "没有找到System Helper，无需卸载哦！\n\n$verify"
    }
    val result = shell.execute("pm uninstall --user 0 $TARGET_PACKAGE")
    val verify = inspectTarget(shell)
    val stillInstalled = isTargetInstalled(verify)
    return if (result.contains("Success", ignoreCase = true) && !stillInstalled) {
        "已完成卸载！\n\n卸载命令结果：$result\n\n=== 卸载后状态 ===\n$verify"
    } else if (!stillInstalled) {
        "已完成卸载！\n\n卸载命令结果：$result\n\n=== 卸载后状态 ===\n$verify"
    } else {
        "卸载未能完成，请检查 Shizuku 授权状态和系统返回信息。\n\n卸载命令结果：$result\n\n$verify"
    }
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("净鉴", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (_: ActivityNotFoundException) { Toast.makeText(context, "未找到可打开链接的浏览器", Toast.LENGTH_LONG).show() }
    catch (_: Exception) { Toast.makeText(context, "无法打开链接", Toast.LENGTH_LONG).show() }
}

private fun openShizuku(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (launchIntent != null) {
        try { context.startActivity(launchIntent) }
        catch (_: Exception) { openUrl(context, SHIZUKU_URL) }
    } else {
        openUrl(context, SHIZUKU_URL)
    }
}

package com.akiyo.cleanguard

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Binds once to a Shizuku UserService and reuses its Binder. */
class ShizukuShellClient(private val context: Context) {
    @Volatile private var service: IShizukuShellService? = null
    @Volatile private var bindError: String? = null
    private var connection: ServiceConnection? = null
    private val lock = Any()

    private val args = Shizuku.UserServiceArgs(ComponentName(context, ShellUserService::class.java))
        .daemon(false)
        .processNameSuffix("shell")
        .tag("jingjian-shell-service")
        .debuggable(false)
        .version(1)

    fun execute(command: String): String {
        if (!Shizuku.pingBinder()) return "Shizuku 服务未运行"
        if (Shizuku.checkSelfPermission() != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            return "尚未获得 Shizuku 授权"
        }
        val remote = service ?: bindAndWait() ?: return bindError ?: "无法连接 Shizuku 服务"
        return try {
            remote.execute(command)
        } catch (e: Exception) {
            service = null
            "Shizuku 命令执行失败：${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun bindAndWait(): IShizukuShellService? = synchronized(lock) {
        service?.let { return it }
        bindError = null
        val latch = CountDownLatch(1)
        val conn = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
                service = IShizukuShellService.Stub.asInterface(binder)
                latch.countDown()
            }
            override fun onServiceDisconnected(name: ComponentName?) {
                service = null
            }
        }
        connection = conn
        try {
            Shizuku.bindUserService(args, conn)
        } catch (e: Exception) {
            bindError = "绑定 Shizuku 服务失败：${e.message ?: e.javaClass.simpleName}"
            connection = null
            return null
        }
        if (!latch.await(12, TimeUnit.SECONDS)) {
            bindError = "连接 Shizuku 服务超时，请检查 Shizuku 是否正常运行"
            try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) { }
            connection = null
            return null
        }
        service
    }

    fun close() {
        synchronized(lock) {
            val conn = connection ?: return
            try { Shizuku.unbindUserService(args, conn, true) } catch (_: Exception) { }
            connection = null
            service = null
        }
    }
}

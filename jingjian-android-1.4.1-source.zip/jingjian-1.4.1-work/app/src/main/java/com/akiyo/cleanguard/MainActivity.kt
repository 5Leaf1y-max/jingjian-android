package com.akiyo.cleanguard

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

private const val REQUEST_CODE = 1001
private const val APP_VERSION = "1.4.1"
private const val PROJECT_URL = "https://github.com/5Leaf1y-max/jingjian-android"
private const val SHIZUKU_URL = "https://shizuku.rikka.app/"

private data class CarrierComponent(
    val packageName: String,
    val title: String,
    val carrier: String,
    val brands: String,
    val verification: String,
    val verified: Boolean
)

private val CARRIER_COMPONENTS = listOf(
    CarrierComponent("com.mobiletools.systemhelper", "System Helper", "中国联通", "多品牌国行设备", "已有公开实机分析", true),
    CarrierComponent("com.oppo.ctautoregist", "运营商自注册", "中国电信", "OPPO / 一加 / realme", "已有公开实机验证", true),
    CarrierComponent("com.coloros.regservice", "RegService", "中国移动", "OPPO / 一加 / realme", "已有公开实机验证", true),
    CarrierComponent("com.xiaomi.registration", "运营商自注册", "中国电信", "小米 / Redmi / POCO", "公开资料有记录，尚缺本项目实机验证", false),
    CarrierComponent("com.miui.dmregservice", "RegService", "中国移动", "小米 / Redmi / POCO", "公开资料有记录，尚缺本项目实机验证", false),
    CarrierComponent("com.miui.regservice", "RegService", "中国移动", "部分旧版 MIUI", "公开学术研究有记录，机型差异需核验", false),
    CarrierComponent("com.vivo.devicereg", "DeviceReg", "中国移动 / 中国电信", "vivo", "公开清单有记录，尚缺本项目实机验证", false)
)

private val Ink = Color(0xFF17263C)
private val Muted = Color(0xFF68778B)
private val Canvas = Color(0xFFF3F6FB)
private val Blue = Color(0xFF315FC5)

class MainActivity : ComponentActivity() {
    private val permissionGranted = mutableStateOf(false)
    private val binderAvailable = mutableStateOf(false)
    private val requestListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) permissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val deadListener = Shizuku.OnBinderDeadListener {
        binderAvailable.value = false
        permissionGranted.value = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching {
            val targetRate = windowManager.defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate } ?: 0f
            if (targetRate > 0f) window.attributes = window.attributes.apply { preferredRefreshRate = targetRate }
        }
        Shizuku.addRequestPermissionResultListener(requestListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refreshShizuku()
        setContent { JingJianApp(binderAvailable.value, permissionGranted.value, onGrant = { requestShizuku() }) }
    }

    override fun onResume() { super.onResume(); refreshShizuku() }

    private fun refreshShizuku() {
        val available = try { Shizuku.pingBinder() && !Shizuku.isPreV11() } catch (_: Exception) { false }
        binderAvailable.value = available
        permissionGranted.value = available && try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                binderAvailable.value = false
                permissionGranted.value = false
                Toast.makeText(this, "请先启动 Shizuku 服务", Toast.LENGTH_LONG).show()
                return
            }
            binderAvailable.value = true
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) permissionGranted.value = true
            else Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Exception) {
            permissionGranted.value = false
            Toast.makeText(this, "无法检查 Shizuku 状态，请确认 Shizuku 正常运行", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(requestListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { HOME("首页"), CHECK("检测"), ACTION("删除"), ABOUT("关于") }

@Composable
private fun JingJianApp(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var installedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var scanDone by remember { mutableStateOf(false) }
    var scanMessage by remember { mutableStateOf("") }
    var deletionReport by remember { mutableStateOf("") }
    var selectedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var command by remember { mutableStateOf("pm list packages -u --user 0") }
    var commandOutput by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPrivacyInfo by remember { mutableStateOf(false) }
    var showFreeNotice by remember { mutableStateOf(true) }
    val activity = context as ComponentActivity
    val executor = remember { Executors.newSingleThreadExecutor() }
    val shell = remember(context) { ShizukuShellClient(context.applicationContext) }

    DisposableEffect(shell, executor) {
        onDispose { shell.close(); executor.shutdownNow() }
    }

    fun runAsync(action: () -> String, onResult: (String) -> Unit) {
        if (busy) return
        busy = true
        executor.execute {
            val result = try { action() } catch (e: Exception) { "操作失败：${e.message ?: e.javaClass.simpleName}" }
            activity.runOnUiThread { onResult(result); busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Canvas, surface = Color.White, onSurface = Ink)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 5.dp) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(when (item) { Tab.HOME -> Icons.Default.Home; Tab.CHECK -> Icons.Default.FactCheck; Tab.ACTION -> Icons.Default.Build; Tab.ABOUT -> Icons.Default.Info }, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("净鉴", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text("ANDROID COMPONENT MANAGER", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Muted, fontWeight = FontWeight.SemiBold)
                    }
                    Surface(color = Color(0xFFE7EEFF), shape = RoundedCornerShape(50)) {
                        Text("V$APP_VERSION", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                when (tab) {
                    Tab.HOME -> {
                        ShizukuStatusCard(shizukuGranted, binderAvailable)
                        HomeHero()
                        ShizukuGuide(binderAvailable, shizukuGranted, onGrant)
                        CarrierIntroCard()
                        DeviceInfoCard()
                    }
                    Tab.CHECK -> {
                        PageHeading("组件检测", "扫描当前用户空间中的运营商预装组件")
                        InfoCard("检测范围", "净鉴使用经过整理的包名清单进行精确匹配，不会根据模糊关键词直接判断或卸载应用。不同品牌、地区和系统版本的预装情况可能不同。")
                        Button(enabled = shizukuGranted && !busy, onClick = {
                            runAsync({ inspectCarrierComponents(shell) }) { output ->
                                if (output.startsWith("Shizuku ") || output.contains("执行失败") || output.contains("无法连接 Shizuku")) {
                                    scanMessage = output
                                    scanDone = false
                                } else {
                                    installedPackages = parseInstalledPackages(output)
                                    scanMessage = "扫描完成"
                                    scanDone = true
                                    selectedPackages = installedPackages.filter { pkg -> CARRIER_COMPONENTS.firstOrNull { it.packageName == pkg }?.verified == true }.toSet()
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text(if (busy) "正在扫描…" else "开始扫描设备")
                        }
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请返回首页，启动 Shizuku 服务并授予净鉴权限。", Color(0xFFFFF1F0))
                        if (!scanDone && scanMessage.isNotBlank()) InfoCard("扫描未能完成", scanMessage, Color(0xFFFFF1F0))
                        if (scanDone) {
                            Surface(color = Color(0xFFEAF2FF), shape = RoundedCornerShape(14.dp)) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("扫描完成", color = Blue, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Text("发现 ${installedPackages.size} 个匹配组件", color = Ink, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            if (installedPackages.isEmpty()) InfoCard("未发现清单内组件", "当前用户空间没有发现已知的运营商预装组件。未命中清单不代表设备中绝对不存在其他运营商组件。", Color(0xFFEAF7EF))
                            CARRIER_COMPONENTS.filter { it.packageName in installedPackages }.forEach { ComponentInfoCard(it) }
                        }
                    }
                    Tab.ACTION -> {
                        PageHeading("删除管理", "仅处理已扫描到的运营商组件")
                        InfoCard("操作说明", "卸载仅作用于当前用户（User 0），不会直接删除系统分区中的原始 APK。系统更新或恢复出厂设置后可能恢复。部分组件可能与运营商注册、VoLTE、短信或设备管理功能有关；如遇异常，可按组件包名使用 pm install-existing 恢复。")
                        if (!scanDone) {
                            InfoCard("尚未扫描设备", "请先进入“检测”页面完成扫描。扫描结果只用于选择当前存在的组件，不会在此显示检测历史。")
                        } else {
                            val available = CARRIER_COMPONENTS.filter { it.packageName in installedPackages }
                            if (available.isEmpty()) InfoCard("没有可删除的目标", "当前没有发现清单内的运营商组件。")
                            else {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("待处理组件", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                                    Spacer(Modifier.weight(1f))
                                    TextButton(onClick = { selectedPackages = available.filter { it.verified }.map { it.packageName }.toSet() }) { Text("选择已验证项") }
                                }
                                available.forEach { component ->
                                    SelectableComponentCard(
                                        component = component,
                                        selected = component.packageName in selectedPackages,
                                        onChecked = { checked -> selectedPackages = if (checked) selectedPackages + component.packageName else selectedPackages - component.packageName }
                                    )
                                }
                                Button(
                                    enabled = shizukuGranted && !busy && selectedPackages.isNotEmpty(),
                                    onClick = { showConfirm = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83D49))
                                ) { Text(if (busy) "正在处理…" else "卸载所选组件（${selectedPackages.size}）") }
                            }
                        }
                        if (deletionReport.isNotBlank()) ResultReportCard(deletionReport)
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请先在首页完成 Shizuku 服务启动和授权。", Color(0xFFFFF1F0))
                        ExpandableDetails("高级功能：手动 Shell 命令") {
                            Text("仅供了解 ADB / Shell 的用户使用。命令会以 Shizuku 当前授权身份执行，请确认内容安全。", color = Muted)
                            OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Shell 命令") }, minLines = 2)
                            Button(enabled = shizukuGranted && !busy && command.isNotBlank(), onClick = { runAsync({ shell.execute(command) }) { commandOutput = it } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "执行中…" else "执行命令") }
                            OutlinedButton(onClick = { copyText(context, command) }, modifier = Modifier.fillMaxWidth()) { Text("复制命令") }
                            if (commandOutput.isNotBlank()) {
                                Text("执行结果", fontWeight = FontWeight.SemiBold)
                                Text(commandOutput, color = Muted)
                                OutlinedButton(onClick = { copyText(context, commandOutput) }, modifier = Modifier.fillMaxWidth()) { Text("复制结果") }
                            }
                        }
                    }
                    Tab.ABOUT -> {
                        PageHeading("关于净鉴", "透明、克制、由你决定")
                        InfoCard("应用简介", "净鉴是一款 Android 系统组件检测与管理工具，帮助用户识别设备中已知的运营商预装组件，并在充分了解风险后自行决定是否从当前用户空间卸载。")
                        InfoCard("作者", "5Leaf1y")
                        InfoCard("联系邮箱", "yeqiuyi524@gmail.com")
                        TextButton(onClick = { openUrl(context, "mailto:yeqiuyi524@gmail.com") }) { Text("通过邮件联系作者") }
                        InfoCard("版本信息", "版本：$APP_VERSION\n包名：com.akiyo.cleanguard\n项目：公开、免费，无广告及付费解锁功能。")
                        TextButton(onClick = { showPrivacyInfo = true }) { Text("隐私政策与个人信息保护说明") }
                        TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问 GitHub 项目主页") }
                    }
                }
            }
        }
    }

    if (showConfirm) {
        val names = CARRIER_COMPONENTS.filter { it.packageName in selectedPackages }.joinToString("\n") { "• ${it.title}（${it.carrier}）\n  ${it.packageName}" }
        val includesUnverified = CARRIER_COMPONENTS.any { it.packageName in selectedPackages && !it.verified }
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认卸载所选组件？") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(names)
                    Text("卸载只针对当前用户空间。原始系统 APK 通常仍保留，可通过 pm install-existing 包名恢复。")
                    if (includesUnverified) Text("注意：所选项目中包含缺少充分实机验证的组件，可能影响设备功能。", color = Color(0xFFB33B45), fontWeight = FontWeight.Bold)
                    Text("请确认你了解风险，并已准备好在出现异常时恢复组件。", color = Muted)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    val targets = selectedPackages.toList()
                    runAsync({ uninstallCarrierComponents(shell, targets) }) { result ->
                        val marker = "\n__REMAINING__\n"
                        val visible = result.substringBefore(marker)
                        val remaining = result.substringAfter(marker, "").lineSequence()
                            .filter { it.startsWith("REMAINING|") }.map { it.removePrefix("REMAINING|").trim() }.toSet()
                        deletionReport = visible
                        installedPackages = remaining
                        selectedPackages = selectedPackages.intersect(remaining)
                    }
                }) { Text("确认卸载", color = Color(0xFFB83D49)) }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("取消") } }
        )
    }

    if (showPrivacyInfo) {
        AlertDialog(
            onDismissRequest = { showPrivacyInfo = false },
            confirmButton = { TextButton(onClick = { showPrivacyInfo = false }) { Text("我知道了") } },
            title = { Text("隐私政策与个人信息保护说明") },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("一、适用范围与基本原则", fontWeight = FontWeight.Bold)
                    Text("净鉴是一款本地运行的 Android 系统组件检测与管理工具。本说明介绍净鉴自身在使用过程中涉及的信息、权限及处理方式。净鉴坚持必要、透明和由用户主动控制的原则。")
                    Text("二、权限与网络访问", fontWeight = FontWeight.Bold)
                    Text("当前版本的 AndroidManifest 未声明 INTERNET 权限，也未声明定位、通讯录、短信、相机、麦克风或电话等敏感权限；项目依赖中未集成广告或统计 SDK。净鉴本身不通过网络上传检测内容。Shizuku Provider 用于接入 Shizuku 服务，不代表净鉴获得了静默或绕过授权的能力。")
                    Text("三、处理的信息及用途", fontWeight = FontWeight.Bold)
                    Text("净鉴会在本机读取设备制造商、型号、Android 版本和系统构建指纹，用于展示设备信息。你主动发起扫描并授予 Shizuku 权限后，净鉴会通过系统包管理命令读取当前用户的已安装包名，并与应用内明确列出的组件包名进行精确匹配。你主动执行卸载时，净鉴会提交对应的当前用户卸载命令，并读取执行后的包安装状态，以展示操作结果。")
                    Text("四、本地处理与保存期限", fontWeight = FontWeight.Bold)
                    Text("设备信息、扫描结果、所选组件、Shell 输出和卸载结果仅在应用运行期间用于界面展示与操作流程管理。当前版本不将这些内容写入云端，也不设置账号或远程用户档案；退出应用或系统回收进程后，运行期间的界面状态可能被清除。复制结果时，内容会由你主动写入系统剪贴板，剪贴板的后续管理由 Android 系统负责。")
                    Text("五、Shizuku 与第三方组件", fontWeight = FontWeight.Bold)
                    Text("净鉴使用 Shizuku 提供的授权接口执行需要更高系统权限的本机命令。是否授权由你在 Shizuku 中确认；你可以在 Shizuku 中撤销授权或停止其服务。Shizuku 自身的运行方式和隐私处理应以其项目说明为准。净鉴不会读取或保存无线调试配对码。")
                    Text("六、卸载操作与风险提示", fontWeight = FontWeight.Bold)
                    Text("只有在你选择目标组件并再次确认后，净鉴才会尝试从当前用户空间卸载。该操作通常不会删除系统分区中的原始 APK，系统更新或恢复出厂设置后可能恢复。卸载可能影响运营商注册、通话、短信或厂商功能。请在操作前核对包名与设备情况，并自行决定是否继续。")
                    Text("七、信息共享、转让与公开", fontWeight = FontWeight.Bold)
                    Text("净鉴当前版本没有将扫描信息发送给开发者或第三方服务器的功能，也不提供账号、广告投放或跨应用跟踪功能。若你主动通过邮件联系作者，邮件内容及地址将由你使用的邮件服务处理，具体规则以相应服务提供方的政策为准。")
                    Text("八、你的控制权", fontWeight = FontWeight.Bold)
                    Text("你可以不授予 Shizuku 权限、随时停止扫描、取消卸载确认，或撤销 Shizuku 授权。卸载净鉴会移除本应用在系统中保存的数据。若你对隐私说明或应用行为有疑问，可通过关于页面所列邮箱联系作者。")
                    Text("九、说明更新", fontWeight = FontWeight.Bold)
                    Text("若后续版本增加新的权限、联网能力或信息处理方式，开发者应相应更新本说明。请以你实际安装版本内展示的内容为准。")
                    Text("联系邮箱：yeqiuyi524@gmail.com", fontWeight = FontWeight.SemiBold)
                }
            }
        )
    }

    if (showFreeNotice) {
        AlertDialog(
            onDismissRequest = { showFreeNotice = false },
            title = { Text("欢迎使用净鉴") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("免费使用 · 开源项目", color = Blue, fontWeight = FontWeight.Bold)
                    Text("净鉴用于识别和管理部分 Android 设备中的运营商预装组件。所有卸载操作均由你主动选择并确认。")
                    Text("项目代码与更新信息可通过 GitHub 查看。", color = Muted)
                    TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问项目主页") }
                }
            },
            confirmButton = { TextButton(onClick = { showFreeNotice = false }) { Text("开始使用") } }
        )
    }
}

@Composable
private fun HomeHero() {
    Box(
        Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF234A9A), Color(0xFF477CE0), Color(0xFF65A5E8))), RoundedCornerShape(24.dp)).padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(color = Color.White.copy(alpha = 0.17f), shape = RoundedCornerShape(50)) {
                Text("DEVICE TRANSPARENCY", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color.White, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            }
            Text("看清预装组件，\n把选择权留给自己。", color = Color.White, fontSize = 25.sp, lineHeight = 33.sp, fontWeight = FontWeight.ExtraBold)
            Text("识别已知运营商组件 · 查看设备状态 · 自主决定是否卸载", color = Color(0xFFE4EDFF), fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun PageHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, fontSize = 13.sp, color = Muted)
    }
}

@Composable
private fun ShizukuStatusCard(granted: Boolean, binderAvailable: Boolean) {
    val accent = if (granted) Color(0xFF16865B) else Color(0xFFB94B4B)
    val bg = if (granted) Color(0xFFE8F7EF) else Color(0xFFFFF0EF)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            Box(Modifier.size(42.dp).background(accent.copy(alpha = 0.13f), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (granted) "✓" else "!", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Shizuku 授权状态", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (granted) "已授权，可以开始检测" else if (binderAvailable) "服务已启动，等待授权" else "尚未连接服务", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(if (granted) "操作仍需你在净鉴内主动确认。" else "请启动 Shizuku，并按照引导完成授权。", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ShizukuGuide(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("快速开始", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                    Text("首次使用需要启动 Shizuku 服务", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起" else "查看教程") }
            }
            if (expanded) {
                Text("1. 安装并打开 Shizuku。")
                OutlinedButton(onClick = { openShizuku(context) }, modifier = Modifier.fillMaxWidth()) { Text("打开 Shizuku") }
                Text("2. 按 Shizuku 指引启动服务。无 Root 设备通常使用无线调试；已 Root 设备可选择 Root 启动方式。", color = Muted)
                Text("3. 返回净鉴，检查服务状态并授予净鉴权限。无线调试配对码由 Android 和 Shizuku 处理，请勿发送给净鉴。", color = Muted)
                OutlinedButton(onClick = { try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (_: Exception) { Toast.makeText(context, "请在系统设置中打开开发者选项", Toast.LENGTH_LONG).show() } }, modifier = Modifier.fillMaxWidth()) { Text("打开开发者选项") }
                Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) { Text("检查状态并授权净鉴") }
                Text("当前状态：${if (shizukuGranted) "已获得授权" else if (binderAvailable) "服务已连接" else "尚未连接"}", color = if (shizukuGranted) Color(0xFF16865B) else Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CarrierIntroCard() {
    var expanded by remember { mutableStateOf(false) }
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF7F7)),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("什么是 System Helper？", color = Color(0xFF9B3038), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("建议阅读 · 了解组件用途与卸载影响", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { expanded = !expanded }) {
                    Text(if (expanded) "收起" else "了解更多")
                }
            }
            if (expanded) {
                Text(
                    "System Helper 是中国联通的设备管理客户端，属于运营商定制预装的遥测组件。部分 OPPO、vivo、小米等品牌的国行系统中可能预装此类组件。它通常位于系统特权分区，普通用户无法像普通应用一样直接卸载。根据部分设备的逆向分析，它可能涉及设备与 SIM 标识（如 IMEI、IMSI、ICCID）、已安装应用列表、应用使用情况、流量统计，以及部分基站、信号和定位相关信息。不同厂商、机型和系统版本的实际行为可能存在差异，以上不代表所有设备都会收集全部信息。",
                    color = Color(0xFF596777), fontSize = 13.sp, lineHeight = 21.sp
                )
                HorizontalDivider(color = Color(0xFFE9DCDD))
                Text(
                    "为什么建议卸载？如果当前用户空间仍安装并启用了该组件，它可能继续运行并访问相关数据。对于重视个人隐私、且不依赖相关厂商功能的用户，卸载当前用户中的组件可以减少它继续运行和访问数据的机会。卸载不会删除系统分区中的原始 APK，系统更新或恢复出厂设置后也可能重新安装；同时可能影响部分厂商功能，请结合自己的设备情况决定。",
                    color = Color(0xFF596777), fontSize = 13.sp, lineHeight = 21.sp
                )
                Text(
                    "净鉴也会识别清单中其他已知的运营商自注册或 RegService 组件。不同组件的归属和验证程度会在检测结果中单独标明；未验证项目默认不勾选。",
                    color = Color(0xFF596777), fontSize = 13.sp, lineHeight = 21.sp
                )
            }
        }
    }
}

@Composable
private fun DeviceInfoCard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("设备信息", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            DeviceInfoRow("净鉴版本", APP_VERSION)
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("设备型号", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("Android 版本", "Android ${android.os.Build.VERSION.RELEASE}（API ${android.os.Build.VERSION.SDK_INT}）")
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("系统指纹", android.os.Build.FINGERPRINT)
        }
    }
}

@Composable
private fun DeviceInfoRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Text(value, color = Ink, fontSize = 13.sp)
    }
}

@Composable
private fun ComponentInfoCard(component: CarrierComponent) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(component.title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text(component.carrier, color = Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(component.packageName, color = Muted, fontSize = 11.sp)
            Text("适用设备：${component.brands}", color = Color(0xFF46566B), fontSize = 12.sp)
            Text(component.verification, color = if (component.verified) Color(0xFF16865B) else Color(0xFFB87524), fontSize = 11.sp)
        }
    }
}

@Composable
private fun SelectableComponentCard(component: CarrierComponent, selected: Boolean, onChecked: (Boolean) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFF0F4FF) else Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = selected, onCheckedChange = onChecked, colors = CheckboxDefaults.colors(checkedColor = Blue))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(component.title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(component.carrier, color = Blue, fontSize = 10.sp)
                }
                Text(component.packageName, color = Muted, fontSize = 10.sp)
                Text("${component.brands} · ${component.verification}", color = if (component.verified) Color(0xFF16865B) else Color(0xFFB87524), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ResultReportCard(report: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (report.contains("失败")) Color(0xFFFFF0EF) else Color(0xFFEAF7EF))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("删除操作结果", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(report, color = Color(0xFF3E4D60), fontSize = 12.sp, lineHeight = 18.sp)
            val context = LocalContext.current
            OutlinedButton(onClick = { copyText(context, report) }, modifier = Modifier.fillMaxWidth()) { Text("复制操作结果") }
        }
    }
}

@Composable
private fun ExpandableDetails(title: String, content: @Composable ColumnScope.() -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) content()
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, containerColor: Color = Color.White) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = containerColor), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 14.sp)
            Text(body, color = Color(0xFF596777), fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

private fun inspectCarrierComponents(shell: ShizukuShellClient): String = shell.execute("pm list packages --user 0")

private fun parseInstalledPackages(output: String): Set<String> = output.lineSequence()
    .map { it.trim() }
    .filter { it.startsWith("package:") }
    .map { it.removePrefix("package:").trim() }
    .filter { pkg -> CARRIER_COMPONENTS.any { it.packageName == pkg } }
    .toSet()

private fun uninstallCarrierComponents(shell: ShizukuShellClient, targets: List<String>): String {
    val allowed = targets.filter { pkg -> CARRIER_COMPONENTS.any { it.packageName == pkg } }.distinct()
    if (allowed.isEmpty()) return "没有选择有效的目标组件。"

    val before = shell.execute("pm list packages --user 0")
    val presentBefore = allowed.filter { pkg ->
        before.lineSequence().any { it.trim() == "package:$pkg" }
    }.toSet()
    val alreadyAbsent = allowed.filterNot { it in presentBefore }
    val commands = presentBefore.joinToString("\n") { pkg ->
        "echo 'TARGET:$pkg'; pm uninstall -k --user 0 '$pkg'"
    }
    val raw = if (commands.isBlank()) "没有执行卸载命令。" else shell.execute(commands)
    val verify = shell.execute("pm list packages --user 0")
    val remaining = presentBefore.filter { pkg ->
        verify.lineSequence().any { it.trim() == "package:$pkg" }
    }
    val removed = presentBefore - remaining.toSet()

    return buildString {
        append("本次选择：${allowed.size} 项\n")
        append("卸载后已不存在：${removed.size} 项\n")
        removed.forEach { append("✓ $it\n") }
        if (alreadyAbsent.isNotEmpty()) {
            append("\n执行前已不在当前用户中：${alreadyAbsent.size} 项\n")
            alreadyAbsent.forEach { append("— $it\n") }
        }
        if (remaining.isNotEmpty()) {
            append("\n卸载后仍然存在：${remaining.size} 项\n")
            remaining.forEach { append("✕ $it\n") }
        }
        append("\n系统返回：\n$raw")
        append("\n\n提示：卸载仅作用于当前用户空间，系统分区中的原始 APK 通常仍保留。")
        append("\n__REMAINING__\n")
        remaining.forEach { append("REMAINING|$it\n") }
    }
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("净鉴", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (_: ActivityNotFoundException) { Toast.makeText(context, "未找到可打开链接的浏览器", Toast.LENGTH_LONG).show() }
    catch (_: Exception) { Toast.makeText(context, "无法打开链接", Toast.LENGTH_LONG).show() }
}

private fun openShizuku(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (launchIntent != null) {
        try { context.startActivity(launchIntent) } catch (_: Exception) { openUrl(context, SHIZUKU_URL) }
    } else openUrl(context, SHIZUKU_URL)
}

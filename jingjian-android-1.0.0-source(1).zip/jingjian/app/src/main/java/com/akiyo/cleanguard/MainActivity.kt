package com.akiyo.cleanguard

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

private const val TARGET_PACKAGE = "com.mobiletools.systemhelper"
private const val REQUEST_CODE = 1001
private const val PREFS_NAME = "jingjian_local"
private const val PREF_FINGERPRINT = "baseline_fingerprint"

class MainActivity : ComponentActivity() {
    private val permissionGranted = mutableStateOf(false)
    private val requestListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) permissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val deadListener = Shizuku.OnBinderDeadListener { permissionGranted.value = false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(requestListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refreshShizuku()
        setContent { JingJianApp(permissionGranted.value, onGrant = { requestShizuku() }) }
    }

    override fun onResume() {
        super.onResume()
        refreshShizuku()
    }

    private fun refreshShizuku() {
        permissionGranted.value = try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                permissionGranted.value = false
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                permissionGranted.value = true
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (_: Exception) { permissionGranted.value = false }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(requestListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { HOME("首页"), CHECK("检测"), ACTION("操作"), ABOUT("关于") }

@Composable
private fun JingJianApp(shizukuGranted: Boolean, onGrant: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var report by remember { mutableStateOf("尚未检测") }
    var updateReport by remember { mutableStateOf("尚未检查系统更新") }
    var command by remember { mutableStateOf("pm list packages -u --user 0 | grep -F $TARGET_PACKAGE") }
    var commandOutput by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPolicy by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val executor = remember { Executors.newSingleThreadExecutor() }
    val shell = remember(context) { ShizukuShellClient(context.applicationContext) }
    val prefs = remember(context) { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }

    DisposableEffect(shell, executor) {
        onDispose {
            shell.close()
            executor.shutdownNow()
        }
    }

    fun runAsync(action: () -> String, onResult: (String) -> Unit) {
        if (busy) return
        busy = true
        executor.execute {
            val result = try { action() } catch (e: Exception) { "操作失败：${e.message ?: e.javaClass.simpleName}" }
            activity.runOnUiThread { onResult(result); busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF356BCE), background = Color(0xFFF5F7FB), surface = Color.White)) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when (item) {
                                    Tab.HOME -> Icons.Default.Home
                                    Tab.CHECK -> Icons.Default.FactCheck
                                    Tab.ACTION -> Icons.Default.Build
                                    Tab.ABOUT -> Icons.Default.Info
                                }, contentDescription = item.label)
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("净鉴", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Android 系统组件检测与管理 · 1.0.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (tab) {
                    Tab.HOME -> {
                        InfoCard("设备状态", "Android ${android.os.Build.VERSION.RELEASE} · ${android.os.Build.MODEL}\n${android.os.Build.MANUFACTURER}")
                        InfoCard("Shizuku 状态", if (shizukuGranted) "已授权，可执行检测操作" else "未授权或服务未启动")
                        Button(onClick = { tab = Tab.CHECK }, modifier = Modifier.fillMaxWidth()) { Text("开始检测") }
                        OutlinedButton(onClick = onGrant, modifier = Modifier.fillMaxWidth()) { Text("检查 / 请求 Shizuku 授权") }
                        InfoCard("系统更新提醒", "系统更新后建议重新检测。净鉴会对比本地保存的构建指纹，并复查目标组件。")
                        OutlinedButton(
                            enabled = shizukuGranted && !busy,
                            onClick = {
                                runAsync({ checkSystemUpdate(context, shell) }) { updateReport = it; report = it }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "检查中…" else "检查系统更新与组件状态") }
                        InfoCard("最近检查", updateReport)
                    }
                    Tab.CHECK -> {
                        InfoCard("SystemHelper 专项检测", "目标包名：$TARGET_PACKAGE\n检测范围：Android 当前用户（User 0）及系统 APK 路径、权限声明、相关进程。")
                        Button(
                            enabled = shizukuGranted && !busy,
                            onClick = { runAsync({ inspectTarget(shell) }) { report = it } },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "检测中…" else "执行专项检测") }
                        OutlinedButton(
                            enabled = shizukuGranted && !busy,
                            onClick = { runAsync({ checkSystemUpdate(context, shell) }) { updateReport = it; report = it } },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("系统更新后复检") }
                        InfoCard("检测结果", report)
                    }
                    Tab.ACTION -> {
                        InfoCard("一键卸载", "仅对 Android 当前用户执行卸载，不会删除系统分区中的 APK。系统更新或恢复出厂设置后可能恢复。卸载系统组件可能影响厂商功能。")
                        Button(enabled = shizukuGranted && !busy, onClick = { showConfirm = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("卸载 SystemHelper（当前用户）")
                        }
                        InfoCard("手动命令", "仅供熟悉 ADB / Shell 的用户使用。命令会以 Shizuku 当前授权身份执行，请确认内容安全。")
                        OutlinedTextField(
                            value = command,
                            onValueChange = { command = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Shell 命令") },
                            minLines = 2
                        )
                        Button(
                            enabled = shizukuGranted && !busy && command.isNotBlank(),
                            onClick = { runAsync({ shell.execute(command) }) { commandOutput = it } },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (busy) "执行中…" else "执行命令") }
                        OutlinedButton(onClick = { copyText(context, command) }, modifier = Modifier.fillMaxWidth()) { Text("复制命令") }
                        InfoCard("命令输出", commandOutput.ifBlank { "暂无输出" })
                        OutlinedButton(onClick = { copyText(context, commandOutput) }, modifier = Modifier.fillMaxWidth()) { Text("复制输出") }
                    }
                    Tab.ABOUT -> {
                        InfoCard("简介", "净鉴是一款面向 Android 用户的系统组件检测与管理工具，旨在帮助用户了解设备中的预装应用、系统权限及运行状态，并提供便捷的检测、卸载与复检功能。")
                        InfoCard("作者", "yeqiuyi524@gmail.com\nby ChatGPT")
                        TextButton(onClick = { showPolicy = true }) { Text("隐私政策与使用规范") }
                    }
                }
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认卸载") },
            text = { Text("将执行 pm uninstall --user 0 $TARGET_PACKAGE。此操作仅对当前用户生效，不会删除系统分区 APK，仍可能影响厂商功能。确定继续吗？") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    runAsync({
                        val uninstall = shell.execute("pm uninstall --user 0 $TARGET_PACKAGE")
                        val verify = inspectTarget(shell)
                        "卸载命令结果：\n$uninstall\n\n--- 卸载后自动复检 ---\n$verify"
                    }) { report = it; tab = Tab.CHECK }
                }) { Text("确认卸载") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("取消") } }
        )
    }

    if (showPolicy) {
        AlertDialog(
            onDismissRequest = { showPolicy = false },
            confirmButton = { TextButton(onClick = { showPolicy = false }) { Text("知道了") } },
            title = { Text("隐私政策与使用规范") },
            text = {
                Text(
                    "净鉴默认在本地处理检测信息，不主动上传设备数据，不包含广告或统计 SDK。检测可能读取设备型号、Android 版本、构建指纹、包名、APK 路径、权限声明与授权状态、相关进程及命令输出。上述信息用于本机检测和结果展示；只有在你主动复制或分享时才会离开应用。\n\n仅在自有或已获授权的设备上使用。卸载系统组件前请确认风险。检测结论仅供参考，敏感权限不等于恶意行为。请遵守所在地法律法规。"
                )
            }
        )
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun inspectTarget(shell: ShizukuShellClient): String {
    val script = """
        echo '=== 构建指纹 ==='
        getprop ro.build.fingerprint
        printf '\n=== 当前用户安装状态 ===\n'
        pm list packages --user 0 | grep -F '$TARGET_PACKAGE' || echo 'User 0 未安装'
        printf '\n=== 包记录（含已卸载记录） ===\n'
        pm list packages -u | grep -F '$TARGET_PACKAGE' || echo '未找到包记录'
        printf '\n=== APK 路径 ===\n'
        pm path '$TARGET_PACKAGE' || true
        printf '\n=== 权限声明与状态（节选） ===\n'
        dumpsys package '$TARGET_PACKAGE' | grep -E 'requested permissions:|install permissions:|runtime permissions:|android.permission.(ACCESS_FINE_LOCATION|ACCESS_COARSE_LOCATION|READ_PHONE_STATE|PACKAGE_USAGE_STATS|QUERY_ALL_PACKAGES|ACCESS_NETWORK_STATE|ACCESS_WIFI_STATE)' | head -n 80
        printf '\n=== 相关进程 ===\n'
        ps -A | grep -F '$TARGET_PACKAGE' || echo '未发现匹配进程'
    """.trimIndent()
    return shell.execute(script)
}

private fun checkSystemUpdate(context: Context, shell: ShizukuShellClient): String {
    val current = android.os.Build.FINGERPRINT
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val previous = prefs.getString(PREF_FINGERPRINT, null)
    val changeText = when {
        previous == null -> "首次建立本地构建指纹基准"
        previous == current -> "构建指纹未变化，暂未发现系统构建更新"
        else -> "检测到构建指纹变化，系统可能已更新；建议检查系统组件"
    }
    val check = inspectTarget(shell)
    val failed = check.contains("Shizuku 服务未运行") || check.contains("尚未获得 Shizuku 授权") || check.contains("无法连接 Shizuku 服务") || check.contains("执行失败") || check.contains("执行超时")
    if (!failed) prefs.edit().putString(PREF_FINGERPRINT, current).apply()
    val saveText = if (failed) "检测未成功，本次未更新本地指纹基准。" else "已将本次指纹保存为新的本地基准。"
    return "$changeText\n\n当前指纹：$current\n\n$check\n\n$saveText"
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("净鉴", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

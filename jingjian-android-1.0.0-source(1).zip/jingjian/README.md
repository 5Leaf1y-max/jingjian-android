# 净鉴 1.0.0

- 应用名称：净鉴
- Application ID：`com.akiyo.cleanguard`
- 版本：`1.0.0`（versionCode 1）
- 技术：Kotlin + Jetpack Compose + Shizuku UserService
- minSdk：26；compileSdk / targetSdk：35
- 默认离线；Manifest 不声明 INTERNET 权限；不包含广告或统计 SDK。

## 构建

1. 在 Android Studio 的 SDK Manager 中安装 Android SDK Platform 35 和 Android SDK Build-Tools 35.x。
2. 确认电脑安装 JDK 17（Android Studio 自带的 JBR 17 通常可用）。
3. Windows 首次构建时，先双击项目根目录的 `build-apk.bat`。脚本会下载 Gradle 8.9、生成 Gradle Wrapper 并构建 Debug APK。
4. APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。
5. Wrapper 生成后，再用 Android Studio 打开项目进行后续编辑和构建。

## 功能

- Shizuku 授权状态检测与权限请求。
- 通过 Shizuku UserService（AIDL Binder）执行 Shell，不再调用已弃用的 `Shizuku.newProcess`。
- SystemHelper（`com.mobiletools.systemhelper`）专项检查：User 0 安装状态、包记录、系统 APK 路径、权限信息节选、相关进程。
- 用户级卸载：`pm uninstall --user 0 com.mobiletools.systemhelper`，卸载后自动复检。
- 本地保存 `ro.build.fingerprint` 基准，系统构建指纹变化后提醒并复检。
- 手动 Shell 命令、输出展示与复制。
- 关于页、作者信息、隐私政策与使用规范。

## 重要限制

- Shizuku 需由用户自行安装并启动，且需明确授予净鉴权限。未获得授权时不会执行 Shell 命令。
- Shizuku UserService 的实际身份取决于 Shizuku 启动方式（通常是 shell UID 2000；若用户使用 Root 后端则可能是 Root）。净鉴本身不申请 Root。
- 检测范围目前以 Android User 0 为主，不代表覆盖设备上的所有用户/工作资料。
- `pm uninstall --user 0` 只对当前用户卸载，不会删除系统分区 APK；OTA 更新或恢复出厂设置后可能恢复。
- 权限声明不等于恶意行为证据；检测结论仅供参考。
- 手动 Shell 命令功能权限较高，仅执行你理解且确认安全的命令。

## 当前验证状态

源码已完成第一轮 Shizuku UserService 迁移和静态检查，但本工作环境没有 Android SDK、Gradle 或 Android 构建工具，尚未完成 Gradle 编译与真机验证。请以实际构建和设备测试结果为准，不要将当前源码视为已验证发布版。

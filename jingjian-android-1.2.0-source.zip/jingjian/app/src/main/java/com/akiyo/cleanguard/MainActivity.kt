package com.akiyo.cleanguard

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

private const val TARGET_PACKAGE = "com.mobiletools.systemhelper"
private const val REQUEST_CODE = 1001
private const val PREFS_NAME = "jingjian_local"
private const val PREF_FINGERPRINT = "baseline_fingerprint"
private const val PREF_WELCOME_SHOWN = "free_notice_shown"
private const val PROJECT_URL = "https://github.com/5Leaf1y-max/jingjian-android"
private const val SHIZUKU_URL = "https://shizuku.rikka.app/"

class MainActivity : ComponentActivity() {
    private val permissionGranted = mutableStateOf(false)
    private val binderAvailable = mutableStateOf(false)
    private val requestListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) permissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val deadListener = Shizuku.OnBinderDeadListener {
        binderAvailable.value = false
        permissionGranted.value = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Shizuku.addRequestPermissionResultListener(requestListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refreshShizuku()
        setContent { JingJianApp(binderAvailable.value, permissionGranted.value, onGrant = { requestShizuku() }) }
    }

    override fun onResume() {
        super.onResume()
        refreshShizuku()
    }

    private fun refreshShizuku() {
        val available = try { Shizuku.pingBinder() && !Shizuku.isPreV11() } catch (_: Exception) { false }
        binderAvailable.value = available
        permissionGranted.value = available && try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Exception) { false }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                binderAvailable.value = false
                permissionGranted.value = false
                Toast.makeText(this, "请先启动 Shizuku 服务", Toast.LENGTH_LONG).show()
                return
            }
            binderAvailable.value = true
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                permissionGranted.value = true
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (_: Exception) {
            permissionGranted.value = false
            Toast.makeText(this, "无法检查 Shizuku 状态，请确认 Shizuku 正常运行", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(requestListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { HOME("首页"), CHECK("检测"), ACTION("操作"), ABOUT("关于") }

@Composable
private fun JingJianApp(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var report by remember { mutableStateOf("尚未检测") }
    var updateReport by remember { mutableStateOf("尚未检查系统更新") }
    var command by remember { mutableStateOf("pm list packages -u --user 0 | grep -F $TARGET_PACKAGE") }
    var commandOutput by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPolicy by remember { mutableStateOf(false) }
    var showPermissions by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val executor = remember { Executors.newSingleThreadExecutor() }
    val shell = remember(context) { ShizukuShellClient(context.applicationContext) }
    val prefs = remember(context) { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    var showFreeNotice by remember(prefs) { mutableStateOf(!prefs.getBoolean(PREF_WELCOME_SHOWN, false)) }

    DisposableEffect(shell, executor) {
        onDispose {
            shell.close()
            executor.shutdownNow()
        }
    }

    fun runAsync(action: () -> String, onResult: (String) -> Unit) {
        if (busy) return
        busy = true
        executor.execute {
            val result = try { action() } catch (e: Exception) { "操作失败：${e.message ?: e.javaClass.simpleName}" }
            activity.runOnUiThread { onResult(result); busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF356BCE), background = Color(0xFFF5F7FB), surface = Color.White)) {
        Scaffold(
            containerColor = Color(0xFFF5F7FB),
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 4.dp) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = {
                                Icon(when (item) {
                                    Tab.HOME -> Icons.Default.Home
                                    Tab.CHECK -> Icons.Default.FactCheck
                                    Tab.ACTION -> Icons.Default.Build
                                    Tab.ABOUT -> Icons.Default.Info
                                }, contentDescription = item.label)
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("净鉴", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text("Android 系统组件检测与管理 · 1.2.0", color = MaterialTheme.colorScheme.onSurfaceVariant)
                when (tab) {
                    Tab.HOME -> {
                        HomeHeroCard()
                        InfoCard("设备情况", "Android ${android.os.Build.VERSION.RELEASE} · ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                        InfoCard("Shizuku 授权状态", when {
                            shizukuGranted -> "服务已连接，净鉴已获得授权。你可以前往底部“检测”页面进行检查。"
                            binderAvailable -> "Shizuku 服务已启动，但净鉴尚未获得授权。请前往“检测”页面完成授权。"
                            else -> "尚未连接 Shizuku 服务。请前往底部“检测”页面查看授权引导。"
                        })
                        InfoCard("什么是 System Helper？", """System Helper是中国联通的设备管理客户端，属于运营商定制预装的遥测组件，OPPO、VIVO、小米等多家品牌的国行系统中都有预装。它通常安装在系统特权分区，拥有较高权限，普通用户无法直接卸载。即使手机插的是其他运营商的SIM卡，它也会向联通的设备管理平台注册并上报数据。

根据逆向结果，它会收集并上报：
• 设备与SIM标识：IMEI、IMSI、ICCID 等；
• 已安装应用列表；
• 过去约24小时内有使用记录的App的前台使用时长与流量统计；
• 部分基站、信号及定位相关信息。

组件行为可能随厂商系统和软件版本变化，具体情况以设备实际版本为准。""")
                        if (report != "尚未检测") StatusInfoCard("最近一次检测", report)
                    }
                    Tab.CHECK -> {
                        InfoCard("系统组件检测", "净鉴会检查System Helper在当前用户中的安装状态，并提供相应的建议。")
                        Button(enabled = shizukuGranted && !busy, onClick = { runAsync({ inspectTarget(shell) }) { report = it } }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (busy) "检测中…" else "开始检测")
                        }
                        OutlinedButton(enabled = shizukuGranted && !busy, onClick = { runAsync({ checkSystemUpdate(context, shell) }) { updateReport = it; report = it } }, modifier = Modifier.fillMaxWidth()) { Text("系统更新后复检") }
                        ResultCard(report)
                        if (report != "尚未检测") Text("详细信息", fontWeight = FontWeight.SemiBold)
                        if (report != "尚未检测") ExpandableDetails("查看原始检测结果", report)
                        if (!shizukuGranted) ShizukuGuide(binderAvailable, onGrant)
                    }
                    Tab.ACTION -> {
                        InfoCard("卸载组件", "如果你已经明白了该组件的行为且认为有必要停用它，可以考虑从当前用户空间卸载。此操作不会删除系统分区中的原始 APK，但是可以做到将其停用。系统更新或恢复出厂设置后它可能会重新安装。卸载后可能影响厂商功能，请在权衡个人隐私与风险后操作。")
                        Button(enabled = shizukuGranted && !busy, onClick = { showConfirm = true }, modifier = Modifier.fillMaxWidth()) { Text("卸载组件") }
                        if (report != "尚未检测") ResultCard(report, title = "最近一次操作 / 复检结果")
                        ExpandableDetails("高级功能：手动 Shell 命令") {
                            Text("仅供了解 ADB / Shell 的用户使用。命令会以 Shizuku 当前授权身份执行，请确认内容安全。")
                            OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Shell 命令") }, minLines = 2)
                            Button(enabled = shizukuGranted && !busy && command.isNotBlank(), onClick = { runAsync({ shell.execute(command) }) { commandOutput = it } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "执行中…" else "执行命令") }
                            OutlinedButton(onClick = { copyText(context, command) }, modifier = Modifier.fillMaxWidth()) { Text("复制命令") }
                            if (commandOutput.isNotBlank()) {
                                Text("执行结果", fontWeight = FontWeight.SemiBold)
                                Text(commandOutput, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                OutlinedButton(onClick = { copyText(context, commandOutput) }, modifier = Modifier.fillMaxWidth()) { Text("复制结果") }
                            }
                        }
                    }
                    Tab.ABOUT -> {
                        InfoCard("简介", "净鉴是一款Android 系统组件检测与管理工具，帮助用户解决设备中的预装组件带来的隐私安全风险。本软件发布于2026年11月12日，完全公开免费无盈利性质。")
                        InfoCard("作者", "5Leaf1y by ChatGPT")
                        TextButton(onClick = { showPermissions = true }) { Text("个人信息与权限收集清单") }
                        TextButton(onClick = { showPolicy = true }) { Text("隐私政策与使用规范") }
                        TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问 GitHub 项目主页") }
                    }
                }
            }
        }
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认卸载组件？") },
            text = { Text("净鉴将尝试从当前用户（User 0）卸载 SystemHelper。不会删除系统分区中的原始 APK，但可能影响依赖它的厂商功能。系统更新或恢复出厂设置后也可能重新出现。确定继续吗？") },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    runAsync({
                        val uninstall = shell.execute("pm uninstall --user 0 $TARGET_PACKAGE")
                        val verify = inspectTarget(shell)
                        "卸载命令结果：\n$uninstall\n\n--- 卸载后复检 ---\n$verify"
                    }) { report = it }
                }) { Text("确认卸载") }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("取消") } }
        )
    }

    if (showPolicy) {
        AlertDialog(
            onDismissRequest = { showPolicy = false },
            confirmButton = { TextButton(onClick = { showPolicy = false }) { Text("知道了") } },
            title = { Text("隐私政策与使用规范") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                    Text("净鉴默认离线运行，不主动上传设备检测数据，不包含广告或统计 SDK。检测结果保存在当前界面；构建指纹基准保存在本机应用设置中。\n\n请仅在自有或已获授权的设备上使用。卸载系统组件前请了解可能影响。检测结论仅供参考，权限较多不等于恶意行为。请遵守所在地法律法规。")
                }
            }
        )
    }

    if (showPermissions) {
        AlertDialog(
            onDismissRequest = { showPermissions = false },
            confirmButton = { TextButton(onClick = { showPermissions = false }) { Text("关闭") } },
            title = { Text("个人信息与权限收集清单") },
            text = {
                Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("一、应用声明权限", fontWeight = FontWeight.Bold)
                    Text("当前 1.2.0 Manifest 未声明 Android 运行时权限，也未声明 INTERNET、定位、电话、通讯录、相机、麦克风或悬浮窗权限。Shizuku Provider 用于连接 Shizuku 服务，不等同于普通运行时权限。")
                    Text("二、设备信息（本地读取）", fontWeight = FontWeight.Bold)
                    Text("读取 Android 版本、设备厂商和型号，以及系统构建指纹，用于显示设备信息和判断构建指纹是否变化。仅在本机处理，不上传。")
                    Text("三、被检测组件的权限信息（不是净鉴自身权限）", fontWeight = FontWeight.Bold)
                    Text("针对当前检测目标 SystemHelper，检测可能显示其已声明的定位、电话状态、应用使用情况、应用列表查询、网络状态和 Wi-Fi 状态等权限。权限声明不等于权限已实际使用，也不能单独证明组件具有恶意行为。")
                    Text("四、Shizuku 授权后的系统操作", fontWeight = FontWeight.Bold)
                    Text("只有你启动 Shizuku 并明确授权净鉴后，应用才会通过 Shizuku UserService 执行检测命令。检测可能读取目标组件的包名、安装状态、APK 路径、权限声明、相关进程和命令输出。卸载操作会执行当前用户级卸载命令。")
                    Text("五、信息去向与撤销", fontWeight = FontWeight.Bold)
                    Text("检测数据默认只在设备本地处理，不上传到净鉴服务器。净鉴不提供账号功能，不收集姓名、手机号或通讯录。你可以在 Shizuku 中撤销净鉴授权，也可以在系统设置中停止或卸载 Shizuku。无线调试配对码由 Android / Shizuku 流程处理，净鉴不会读取、收集或保存配对码。")
                    Text("六、通知与悬浮窗", fontWeight = FontWeight.Bold)
                    Text("净鉴不申请通知或悬浮窗权限。Shizuku 自身如需通知权限，请按 Shizuku 应用内提示自行决定。")
                }
            }
        )
    }

    if (showFreeNotice) {
        AlertDialog(
            onDismissRequest = { showFreeNotice = false; prefs.edit().putBoolean(PREF_WELCOME_SHOWN, true).apply() },
            title = { Text("欢迎使用净鉴") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("免费使用 · 公开项目", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("净鉴是一款免费的 Android 系统组件检测与管理工具。")
                    Text("本应用免费提供，不收取使用费用；不含广告及付费解锁功能。项目代码与更新信息可通过 GitHub 查看。")
                    Text(PROJECT_URL, color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问项目主页") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (showFreeNotice) prefs.edit().putBoolean(PREF_WELCOME_SHOWN, true).apply()
                    showFreeNotice = false
                }) { Text("开始使用") }
            }
        )
    }
}

@Composable
private fun ShizukuGuide(binderAvailable: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Shizuku 授权引导", fontWeight = FontWeight.Bold)
            Text("净鉴需要通过 Shizuku 执行系统组件检测。授权由你主动确认，净鉴不会绕过系统授权。")
            Text("1. 安装并打开 Shizuku。")
            OutlinedButton(onClick = { openShizuku(context) }, modifier = Modifier.fillMaxWidth()) { Text("打开 Shizuku") }
            TextButton(onClick = { openUrl(context, SHIZUKU_URL) }) { Text("查看 Shizuku 官方说明") }
            Text("2. 启动 Shizuku 服务。无 Root 设备通常使用无线调试；已 Root 设备可在 Shizuku 中选择 Root 启动方式。")
            Text("3. 无线调试配对：在 Android 开发者选项中开启无线调试，再回到 Shizuku 选择“通过无线调试启动”，按系统提示输入配对码。配对码由系统和 Shizuku 处理，不要发送给净鉴。")
            OutlinedButton(onClick = {
                try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
                catch (_: Exception) { Toast.makeText(context, "请在系统设置中打开开发者选项", Toast.LENGTH_LONG).show() }
            }, modifier = Modifier.fillMaxWidth()) { Text("打开开发者选项") }
            Text("4. 返回 Shizuku 启动服务，再回到净鉴检查状态并授权。Shizuku 可能会提示开启它自己的通知权限，这不是净鉴的必需权限。")
            Text("当前状态：${if (binderAvailable) "Shizuku 服务已连接" else "尚未连接 Shizuku 服务"}", color = if (binderAvailable) Color(0xFF23834A) else MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) { Text("检查状态并授权净鉴") }
        }
    }
}

@Composable
private fun ResultCard(report: String, title: String = "检测结论") {
    val failed = report == "尚未检测" || summaryFor(report).startsWith("检测未能完成")
    val installed = report != "尚未检测" && isTargetInstalled(report)
    val accent = when {
        failed -> Color(0xFF64748B)
        installed -> Color(0xFFDC4545)
        else -> Color(0xFF229B62)
    }
    val container = when {
        failed -> Color(0xFFF1F4F8)
        installed -> Color(0xFFFFEEEE)
        else -> Color(0xFFEAF7EF)
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = accent)
            Text(if (report == "尚未检测") "尚未检测" else summaryFor(report), color = Color(0xFF263238))
        }
    }
}

@Composable
private fun StatusInfoCard(title: String, report: String) {
    val installed = isTargetInstalled(report)
    val failed = summaryFor(report).startsWith("检测未能完成")
    val accent = when { failed -> Color(0xFF64748B); installed -> Color(0xFFDC4545); else -> Color(0xFF229B62) }
    val container = when { failed -> Color(0xFFF1F4F8); installed -> Color(0xFFFFEEEE); else -> Color(0xFFEAF7EF) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = accent)
            Text(summaryFor(report), color = Color(0xFF263238))
        }
    }
}

@Composable
private fun HomeHeroCard() {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF1FF))) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("设备隐私概览", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2456A6))
            Text("关注预装系统组件的安装状态与数据访问行为", color = Color(0xFF49658F))
            Text("本地检测 · 自主授权 · 由你决定", fontSize = 12.sp, color = Color(0xFF60789D))
        }
    }
}

private fun isTargetInstalled(report: String): Boolean {
    val currentUserSection = report.substringAfter("=== 当前用户安装状态 ===", "")
        .substringBefore("=== 包记录（含已卸载记录） ===")
    return currentUserSection.contains("package:$TARGET_PACKAGE")
}

private fun summaryFor(report: String): String {
    if (report == "尚未检测") return report
    if (!report.contains("=== 当前用户安装状态 ===") || report.contains("Shizuku 服务未运行") || report.contains("尚未获得 Shizuku 授权") || report.contains("无法连接 Shizuku 服务") || report.contains("执行失败") || report.contains("执行超时") || report.contains("操作失败：")) {
        return "检测未能完成。请检查 Shizuku 服务和净鉴授权状态，然后重新检测。"
    }
    return if (isTargetInstalled(report)) {
        "当前用户空间发现System Helper，这可能导致您的用户数据被上传。"
    } else {
        "当前用户空间未发现System Helper，但系统分区中可能仍保留原始 APK（目前已无法运行，可以放心）。仍要注意的是，厂商系统更新或恢复出厂设置后可能重新安装。"
    }
}

@Composable
private fun ExpandableDetails(title: String, body: String) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(14.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ExpandableDetails(title: String, content: @Composable ColumnScope.() -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) content()
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun inspectTarget(shell: ShizukuShellClient): String {
    val script = """
        echo '=== 构建指纹 ==='
        getprop ro.build.fingerprint
        printf '\n=== 当前用户安装状态 ===\n'
        pm list packages --user 0 | grep -F '$TARGET_PACKAGE' || echo 'User 0 未安装'
        printf '\n=== 包记录（含已卸载记录） ===\n'
        pm list packages -u | grep -F '$TARGET_PACKAGE' || echo '未找到包记录'
        printf '\n=== APK 路径 ===\n'
        pm path '$TARGET_PACKAGE' || true
        printf '\n=== 权限声明与状态（节选） ===\n'
        dumpsys package '$TARGET_PACKAGE' | grep -E 'requested permissions:|install permissions:|runtime permissions:|android.permission.(ACCESS_FINE_LOCATION|ACCESS_COARSE_LOCATION|READ_PHONE_STATE|PACKAGE_USAGE_STATS|QUERY_ALL_PACKAGES|ACCESS_NETWORK_STATE|ACCESS_WIFI_STATE)' | head -n 80
        printf '\n=== 相关进程 ===\n'
        ps -A | grep -F '$TARGET_PACKAGE' || echo '未发现匹配进程'
    """.trimIndent()
    return shell.execute(script)
}

private fun checkSystemUpdate(context: Context, shell: ShizukuShellClient): String {
    val current = android.os.Build.FINGERPRINT
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val previous = prefs.getString(PREF_FINGERPRINT, null)
    val changeText = when {
        previous == null -> "首次建立本地构建指纹基准"
        previous == current -> "构建指纹未变化，暂未发现系统构建更新"
        else -> "检测到构建指纹变化，系统可能已更新；建议检查系统组件"
    }
    val check = inspectTarget(shell)
    val failed = check.contains("Shizuku 服务未运行") || check.contains("尚未获得 Shizuku 授权") || check.contains("无法连接 Shizuku 服务") || check.contains("执行失败") || check.contains("执行超时")
    if (!failed) prefs.edit().putString(PREF_FINGERPRINT, current).apply()
    val saveText = if (failed) "检测未成功，本次未更新本地指纹基准。" else "已将本次指纹保存为新的本地基准。"
    return "$changeText\n\n当前指纹：$current\n\n$check\n\n$saveText"
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("净鉴", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (_: ActivityNotFoundException) { Toast.makeText(context, "未找到可打开链接的浏览器", Toast.LENGTH_LONG).show() }
    catch (_: Exception) { Toast.makeText(context, "无法打开链接", Toast.LENGTH_LONG).show() }
}

private fun openShizuku(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (launchIntent != null) {
        try { context.startActivity(launchIntent) }
        catch (_: Exception) { openUrl(context, SHIZUKU_URL) }
    } else {
        openUrl(context, SHIZUKU_URL)
    }
}

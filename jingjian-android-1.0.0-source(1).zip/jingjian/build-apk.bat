@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "GRADLE_VERSION=8.9"
set "TOOLS_DIR=%LOCALAPPDATA%\JingJianBuildTools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"

if not exist "app\build.gradle.kts" (
  echo Please run this script from the JingJian project root.
  pause
  exit /b 1
)

if not exist "local.properties" (
  if defined ANDROID_HOME (
    set "ANDROID_SDK_PATH=%ANDROID_HOME%"
  ) else if defined ANDROID_SDK_ROOT (
    set "ANDROID_SDK_PATH=%ANDROID_SDK_ROOT%"
  ) else (
    set "ANDROID_SDK_PATH=%LOCALAPPDATA%\Android\Sdk"
  )
  if not exist "!ANDROID_SDK_PATH!\platforms\android-35\android.jar" (
    echo Android SDK Platform 35 was not found.
    echo Open Android Studio ^> SDK Manager and install Android SDK Platform 35 first.
    echo Expected SDK location: !ANDROID_SDK_PATH!
    pause
    exit /b 1
  )
  >local.properties echo sdk.dir=!ANDROID_SDK_PATH:\=/*!
)

where gradle >nul 2>nul
if not errorlevel 1 (
  set "GRADLE_CMD=gradle"
) else (
  if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
    if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
    echo Downloading Gradle %GRADLE_VERSION% (first run only)...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $zip=Join-Path $env:TEMP 'gradle-%GRADLE_VERSION%-bin.zip'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath '%TOOLS_DIR%' -Force; Remove-Item $zip -Force"
    if errorlevel 1 (
      echo Gradle download failed. Check network access and try again.
      pause
      exit /b 1
    )
  )
  set "GRADLE_CMD=%GRADLE_HOME_LOCAL%\bin\gradle.bat"
)

if not exist "gradle\wrapper\gradle-wrapper.jar" (
  echo Creating Gradle Wrapper...
  call "%GRADLE_CMD%" wrapper --gradle-version %GRADLE_VERSION%
  if errorlevel 1 exit /b 1
)

call gradlew.bat assembleDebug
if errorlevel 1 (
  echo Build failed. Copy the complete error output when asking for help.
  pause
  exit /b 1
)

echo.
echo APK created: app\build\outputs\apk\debug\app-debug.apk
pause

package com.akiyo.cleanguard

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

private const val REQUEST_CODE = 1001
private const val APP_VERSION = "1.4.0"
private const val PROJECT_URL = "https://github.com/5Leaf1y-max/jingjian-android"
private const val SHIZUKU_URL = "https://shizuku.rikka.app/"

private data class CarrierComponent(
    val packageName: String,
    val title: String,
    val carrier: String,
    val brands: String,
    val verification: String,
    val verified: Boolean
)

private val CARRIER_COMPONENTS = listOf(
    CarrierComponent("com.mobiletools.systemhelper", "System Helper", "中国联通", "多品牌国行设备", "已有公开设备验证", true),
    CarrierComponent("com.oppo.ctautoregist", "运营商自注册", "中国电信", "OPPO / 一加 / realme", "已有公开设备验证", true),
    CarrierComponent("com.coloros.regservice", "RegService", "中国移动", "OPPO / 一加 / realme", "已有公开设备验证", true),
    CarrierComponent("com.xiaomi.registration", "运营商自注册", "中国电信", "小米 / Redmi / POCO", "已有公开设备验证", true),
    CarrierComponent("com.miui.dmregservice", "RegService", "中国移动", "小米 / Redmi / POCO", "已有公开设备验证", true),
    CarrierComponent("com.vivo.devicereg", "DeviceReg", "中国移动 / 中国电信", "vivo", "部分机型卸载可能受限", true),
    CarrierComponent("com.huawei.android.UEInfoCheck", "UE 信息检查", "中国电信", "华为 / 旧荣耀", "公开清单标记已验证", true),
    CarrierComponent("com.huawei.android.AutoRegSms", "运营商自注册短信", "中国电信", "华为 / 旧荣耀", "公开清单标记已验证", true),
    CarrierComponent("com.huawei.regservice", "RegService", "中国移动", "华为", "公开清单标记已验证", true),
    CarrierComponent("com.hihonor.android.UEInfoCheck", "UE 信息检查", "中国电信", "荣耀", "尚缺少充分实机验证", false),
    CarrierComponent("com.hihonor.android.AutoRegSms", "运营商自注册短信", "中国电信", "荣耀", "尚缺少充分实机验证", false),
    CarrierComponent("com.hihonor.regservice", "RegService", "中国移动", "荣耀", "尚缺少充分实机验证", false),
    CarrierComponent("com.meizu.regservice", "RegService", "运营商待核验", "魅族 / Flyme", "尚缺少充分实机验证", false),
    CarrierComponent("cn.nubia.register", "运营商注册服务", "中国电信", "努比亚（部分旧机型）", "尚缺少充分实机验证", false)
)

private val Ink = Color(0xFF17263C)
private val Muted = Color(0xFF68778B)
private val Canvas = Color(0xFFF3F6FB)
private val Blue = Color(0xFF315FC5)

class MainActivity : ComponentActivity() {
    private val permissionGranted = mutableStateOf(false)
    private val binderAvailable = mutableStateOf(false)
    private val requestListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE) permissionGranted.value = grantResult == PackageManager.PERMISSION_GRANTED
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { refreshShizuku() }
    private val deadListener = Shizuku.OnBinderDeadListener {
        binderAvailable.value = false
        permissionGranted.value = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        runCatching {
            val targetRate = windowManager.defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate } ?: 0f
            if (targetRate > 0f) window.attributes = window.attributes.apply { preferredRefreshRate = targetRate }
        }
        Shizuku.addRequestPermissionResultListener(requestListener)
        Shizuku.addBinderReceivedListener(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refreshShizuku()
        setContent { JingJianApp(binderAvailable.value, permissionGranted.value, onGrant = { requestShizuku() }) }
    }

    override fun onResume() { super.onResume(); refreshShizuku() }

    private fun refreshShizuku() {
        val available = try { Shizuku.pingBinder() && !Shizuku.isPreV11() } catch (_: Exception) { false }
        binderAvailable.value = available
        permissionGranted.value = available && try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Exception) { false }
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder() || Shizuku.isPreV11()) {
                binderAvailable.value = false
                permissionGranted.value = false
                Toast.makeText(this, "请先启动 Shizuku 服务", Toast.LENGTH_LONG).show()
                return
            }
            binderAvailable.value = true
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) permissionGranted.value = true
            else Shizuku.requestPermission(REQUEST_CODE)
        } catch (_: Exception) {
            permissionGranted.value = false
            Toast.makeText(this, "无法检查 Shizuku 状态，请确认 Shizuku 正常运行", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(requestListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }
}

private enum class Tab(val label: String) { HOME("首页"), CHECK("检测"), ACTION("删除"), ABOUT("关于") }

@Composable
private fun JingJianApp(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableStateOf(Tab.HOME) }
    var installedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var scanDone by remember { mutableStateOf(false) }
    var scanMessage by remember { mutableStateOf("") }
    var deletionReport by remember { mutableStateOf("") }
    var selectedPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var command by remember { mutableStateOf("pm list packages -u --user 0") }
    var commandOutput by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }
    var showPrivacyInfo by remember { mutableStateOf(false) }
    var showFreeNotice by remember { mutableStateOf(true) }
    val activity = context as ComponentActivity
    val executor = remember { Executors.newSingleThreadExecutor() }
    val shell = remember(context) { ShizukuShellClient(context.applicationContext) }

    DisposableEffect(shell, executor) {
        onDispose { shell.close(); executor.shutdownNow() }
    }

    fun runAsync(action: () -> String, onResult: (String) -> Unit) {
        if (busy) return
        busy = true
        executor.execute {
            val result = try { action() } catch (e: Exception) { "操作失败：${e.message ?: e.javaClass.simpleName}" }
            activity.runOnUiThread { onResult(result); busy = false }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, background = Canvas, surface = Color.White, onSurface = Ink)) {
        Scaffold(
            containerColor = Canvas,
            bottomBar = {
                NavigationBar(containerColor = Color.White, tonalElevation = 5.dp) {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(when (item) { Tab.HOME -> Icons.Default.Home; Tab.CHECK -> Icons.Default.FactCheck; Tab.ACTION -> Icons.Default.Build; Tab.ABOUT -> Icons.Default.Info }, contentDescription = item.label) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("净鉴", fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
                        Text("ANDROID COMPONENT MANAGER", fontSize = 10.sp, letterSpacing = 1.5.sp, color = Muted, fontWeight = FontWeight.SemiBold)
                    }
                    Surface(color = Color(0xFFE7EEFF), shape = RoundedCornerShape(50)) {
                        Text("V$APP_VERSION", Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Blue, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                when (tab) {
                    Tab.HOME -> {
                        HomeHero()
                        ShizukuStatusCard(shizukuGranted, binderAvailable)
                        ShizukuGuide(binderAvailable, shizukuGranted, onGrant)
                        CarrierIntroCard()
                        DeviceInfoCard()
                    }
                    Tab.CHECK -> {
                        PageHeading("组件检测", "扫描当前用户空间中的运营商预装组件")
                        InfoCard("检测范围", "净鉴使用经过整理的包名清单进行精确匹配，不会根据模糊关键词直接判断或卸载应用。不同品牌、地区和系统版本的预装情况可能不同。")
                        Button(enabled = shizukuGranted && !busy, onClick = {
                            runAsync({ inspectCarrierComponents(shell) }) { output ->
                                if (output.startsWith("Shizuku ") || output.contains("执行失败") || output.contains("无法连接 Shizuku")) {
                                    scanMessage = output
                                    scanDone = false
                                } else {
                                    installedPackages = parseInstalledPackages(output)
                                    scanMessage = "扫描完成"
                                    scanDone = true
                                    selectedPackages = installedPackages.filter { pkg -> CARRIER_COMPONENTS.firstOrNull { it.packageName == pkg }?.verified == true }.toSet()
                                }
                            }
                        }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                            Text(if (busy) "正在扫描…" else "开始扫描设备")
                        }
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请返回首页，启动 Shizuku 服务并授予净鉴权限。", Color(0xFFFFF1F0))
                        if (!scanDone && scanMessage.isNotBlank()) InfoCard("扫描未能完成", scanMessage, Color(0xFFFFF1F0))
                        if (scanDone) {
                            Surface(color = Color(0xFFEAF2FF), shape = RoundedCornerShape(14.dp)) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("扫描完成", color = Blue, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    Text("发现 ${installedPackages.size} 个匹配组件", color = Ink, fontWeight = FontWeight.SemiBold)
                                }
                            }
                            if (installedPackages.isEmpty()) InfoCard("未发现清单内组件", "当前用户空间没有发现已知的运营商预装组件。未命中清单不代表设备中绝对不存在其他运营商组件。", Color(0xFFEAF7EF))
                            CARRIER_COMPONENTS.filter { it.packageName in installedPackages }.forEach { ComponentInfoCard(it) }
                        }
                    }
                    Tab.ACTION -> {
                        PageHeading("删除管理", "仅处理已扫描到的运营商组件")
                        InfoCard("操作说明", "卸载仅作用于当前用户（User 0），不会直接删除系统分区中的原始 APK。系统更新或恢复出厂设置后可能恢复。部分组件可能与运营商注册、VoLTE、短信或设备管理功能有关；如遇异常，可按组件包名使用 pm install-existing 恢复。")
                        if (!scanDone) {
                            InfoCard("尚未扫描设备", "请先进入“检测”页面完成扫描。扫描结果只用于选择当前存在的组件，不会在此显示检测历史。")
                        } else {
                            val available = CARRIER_COMPONENTS.filter { it.packageName in installedPackages }
                            if (available.isEmpty()) InfoCard("没有可删除的目标", "当前没有发现清单内的运营商组件。")
                            else {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Text("待处理组件", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink)
                                    Spacer(Modifier.weight(1f))
                                    TextButton(onClick = { selectedPackages = available.filter { it.verified }.map { it.packageName }.toSet() }) { Text("选择已验证项") }
                                }
                                available.forEach { component ->
                                    SelectableComponentCard(
                                        component = component,
                                        selected = component.packageName in selectedPackages,
                                        onChecked = { checked -> selectedPackages = if (checked) selectedPackages + component.packageName else selectedPackages - component.packageName }
                                    )
                                }
                                Button(
                                    enabled = shizukuGranted && !busy && selectedPackages.isNotEmpty(),
                                    onClick = { showConfirm = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB83D49))
                                ) { Text(if (busy) "正在处理…" else "卸载所选组件（${selectedPackages.size}）") }
                            }
                        }
                        if (deletionReport.isNotBlank()) ResultReportCard(deletionReport)
                        if (!shizukuGranted) InfoCard("需要 Shizuku 授权", "请先在首页完成 Shizuku 服务启动和授权。", Color(0xFFFFF1F0))
                        ExpandableDetails("高级功能：手动 Shell 命令") {
                            Text("仅供了解 ADB / Shell 的用户使用。命令会以 Shizuku 当前授权身份执行，请确认内容安全。", color = Muted)
                            OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Shell 命令") }, minLines = 2)
                            Button(enabled = shizukuGranted && !busy && command.isNotBlank(), onClick = { runAsync({ shell.execute(command) }) { commandOutput = it } }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "执行中…" else "执行命令") }
                            OutlinedButton(onClick = { copyText(context, command) }, modifier = Modifier.fillMaxWidth()) { Text("复制命令") }
                            if (commandOutput.isNotBlank()) {
                                Text("执行结果", fontWeight = FontWeight.SemiBold)
                                Text(commandOutput, color = Muted)
                                OutlinedButton(onClick = { copyText(context, commandOutput) }, modifier = Modifier.fillMaxWidth()) { Text("复制结果") }
                            }
                        }
                    }
                    Tab.ABOUT -> {
                        PageHeading("关于净鉴", "透明、克制、由你决定")
                        InfoCard("应用简介", "净鉴是一款 Android 系统组件检测与管理工具，帮助用户识别设备中已知的运营商预装组件，并在充分了解风险后自行决定是否从当前用户空间卸载。")
                        InfoCard("作者", "5Leaf1y")
                        InfoCard("版本信息", "版本：$APP_VERSION\n包名：com.akiyo.cleanguard\n项目：公开、免费，无广告及付费解锁功能。")
                        TextButton(onClick = { showPrivacyInfo = true }) { Text("个人信息、权限收集和使用规范") }
                        TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问 GitHub 项目主页") }
                    }
                }
            }
        }
    }

    if (showConfirm) {
        val names = CARRIER_COMPONENTS.filter { it.packageName in selectedPackages }.joinToString("\n") { "• ${it.title}（${it.carrier}）\n  ${it.packageName}" }
        val includesUnverified = CARRIER_COMPONENTS.any { it.packageName in selectedPackages && !it.verified }
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("确认卸载所选组件？") },
            text = {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(names)
                    Text("卸载只针对当前用户空间。原始系统 APK 通常仍保留，可通过 pm install-existing 包名恢复。")
                    if (includesUnverified) Text("注意：所选项目中包含缺少充分实机验证的组件，可能影响设备功能。", color = Color(0xFFB33B45), fontWeight = FontWeight.Bold)
                    Text("请确认你了解风险，并已准备好在出现异常时恢复组件。", color = Muted)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showConfirm = false
                    val targets = selectedPackages.toList()
                    runAsync({ uninstallCarrierComponents(shell, targets) }) { result ->
                        val marker = "\n__REMAINING__\n"
                        val visible = result.substringBefore(marker)
                        val remaining = result.substringAfter(marker, "").lineSequence()
                            .filter { it.startsWith("REMAINING|") }.map { it.removePrefix("REMAINING|").trim() }.toSet()
                        deletionReport = visible
                        installedPackages = remaining
                        selectedPackages = selectedPackages.intersect(remaining)
                    }
                }) { Text("确认卸载", color = Color(0xFFB83D49)) }
            },
            dismissButton = { TextButton(onClick = { showConfirm = false }) { Text("取消") } }
        )
    }

    if (showPrivacyInfo) {
        AlertDialog(
            onDismissRequest = { showPrivacyInfo = false },
            confirmButton = { TextButton(onClick = { showPrivacyInfo = false }) { Text("我知道了") } },
            title = { Text("个人信息、权限收集和使用规范") },
            text = {
                Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("一、权限说明", fontWeight = FontWeight.Bold)
                    Text("净鉴不主动申请互联网、定位、电话号码、通讯录、相机、麦克风和悬浮窗等运行时权限。Shizuku 用于在你明确授权后执行本机检测和管理操作。")
                    Text("二、设备信息", fontWeight = FontWeight.Bold)
                    Text("净鉴会读取设备型号、Android 版本和系统指纹用于本机展示。扫描与操作结果在本机处理，不会自动上传给开发者或其他服务器。")
                    Text("三、检测范围", fontWeight = FontWeight.Bold)
                    Text("净鉴通过内置的精确包名清单识别已知运营商组件。组件名称、权限声明或被识别为预装应用，并不单独证明其存在恶意行为；不同厂商和系统版本的实际行为可能不同。")
                    Text("四、卸载操作", fontWeight = FontWeight.Bold)
                    Text("只有在你主动选择组件并二次确认后，净鉴才会尝试从当前用户空间卸载。卸载可能影响运营商注册、通话、短信或厂商功能。系统更新或恢复出厂设置后可能重新安装。")
                    Text("五、恢复与责任", fontWeight = FontWeight.Bold)
                    Text("如出现异常，可尝试使用 pm install-existing 包名恢复组件。请仅在自己拥有或已获得明确授权的设备上使用，并在操作前备份重要数据。检测结论仅供参考，最终决定由你自行作出。")
                }
            }
        )
    }

    if (showFreeNotice) {
        AlertDialog(
            onDismissRequest = { showFreeNotice = false },
            title = { Text("欢迎使用净鉴") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("免费使用 · 开源项目", color = Blue, fontWeight = FontWeight.Bold)
                    Text("净鉴用于识别和管理部分 Android 设备中的运营商预装组件。所有卸载操作均由你主动选择并确认。")
                    Text("项目代码与更新信息可通过 GitHub 查看。", color = Muted)
                    TextButton(onClick = { openUrl(context, PROJECT_URL) }) { Text("访问项目主页") }
                }
            },
            confirmButton = { TextButton(onClick = { showFreeNotice = false }) { Text("开始使用") } }
        )
    }
}

@Composable
private fun HomeHero() {
    Box(
        Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF234A9A), Color(0xFF477CE0), Color(0xFF65A5E8))), RoundedCornerShape(24.dp)).padding(20.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(color = Color.White.copy(alpha = 0.17f), shape = RoundedCornerShape(50)) {
                Text("DEVICE TRANSPARENCY", Modifier.padding(horizontal = 11.dp, vertical = 6.dp), color = Color.White, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
            }
            Text("看清预装组件，\n把选择权留给自己。", color = Color.White, fontSize = 25.sp, lineHeight = 33.sp, fontWeight = FontWeight.ExtraBold)
            Text("识别已知运营商组件 · 查看设备状态 · 自主决定是否卸载", color = Color(0xFFE4EDFF), fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

@Composable
private fun PageHeading(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
        Text(subtitle, fontSize = 13.sp, color = Muted)
    }
}

@Composable
private fun ShizukuStatusCard(granted: Boolean, binderAvailable: Boolean) {
    val accent = if (granted) Color(0xFF16865B) else Color(0xFFB94B4B)
    val bg = if (granted) Color(0xFFE8F7EF) else Color(0xFFFFF0EF)
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            Box(Modifier.size(42.dp).background(accent.copy(alpha = 0.13f), CircleShape), contentAlignment = Alignment.Center) {
                Text(if (granted) "✓" else "!", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Shizuku 授权状态", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(if (granted) "已授权，可以开始检测" else if (binderAvailable) "服务已启动，等待授权" else "尚未连接服务", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(if (granted) "操作仍需你在净鉴内主动确认。" else "请启动 Shizuku，并按照引导完成授权。", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ShizukuGuide(binderAvailable: Boolean, shizukuGranted: Boolean, onGrant: () -> Unit) {
    val context = LocalContext.current
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("快速开始", fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                    Text("首次使用需要启动 Shizuku 服务", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起" else "查看教程") }
            }
            if (expanded) {
                Text("1. 安装并打开 Shizuku。")
                OutlinedButton(onClick = { openShizuku(context) }, modifier = Modifier.fillMaxWidth()) { Text("打开 Shizuku") }
                Text("2. 按 Shizuku 指引启动服务。无 Root 设备通常使用无线调试；已 Root 设备可选择 Root 启动方式。", color = Muted)
                Text("3. 返回净鉴，检查服务状态并授予净鉴权限。无线调试配对码由 Android 和 Shizuku 处理，请勿发送给净鉴。", color = Muted)
                OutlinedButton(onClick = { try { context.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) } catch (_: Exception) { Toast.makeText(context, "请在系统设置中打开开发者选项", Toast.LENGTH_LONG).show() } }, modifier = Modifier.fillMaxWidth()) { Text("打开开发者选项") }
                Button(onClick = onGrant, modifier = Modifier.fillMaxWidth()) { Text("检查状态并授权净鉴") }
                Text("当前状态：${if (shizukuGranted) "已获得授权" else if (binderAvailable) "服务已连接" else "尚未连接"}", color = if (shizukuGranted) Color(0xFF16865B) else Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CarrierIntroCard() {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("认识运营商预装组件", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("它们是什么？为什么需要检测？", color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起" else "了解更多") }
            }
            Text("部分国行 Android 设备会预装运营商终端管理或自注册组件。它们通常没有桌面图标，可能在系统后台运行。", color = Color(0xFF42536A), fontSize = 13.sp, lineHeight = 20.sp)
            if (expanded) {
                HorizontalDivider(color = Color(0xFFE9EDF4))
                Text("这些组件可能用于 SIM 卡注册、终端识别、网络运维或运营商业务适配。公开分析显示，部分实现还涉及设备标识、应用列表或网络状态等信息；但不同组件的功能和实际行为并不相同，不能把某一款组件的行为套用到所有设备。", color = Color(0xFF42536A), fontSize = 13.sp, lineHeight = 21.sp)
                Text("净鉴只按明确的包名清单识别目标，不会仅凭名称相似就判定应用属于运营商组件。卸载可能影响注册、通话、短信或其他厂商功能，因此请先查看检测结果，再自行选择。", color = Color(0xFF42536A), fontSize = 13.sp, lineHeight = 21.sp)
            }
            Surface(color = Color(0xFFF0F4FC), shape = RoundedCornerShape(10.dp)) {
                Text("检测不等于恶意判定；是否卸载，由你决定。", Modifier.fillMaxWidth().padding(11.dp), color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun DeviceInfoCard() {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("设备信息", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Ink)
            DeviceInfoRow("净鉴版本", APP_VERSION)
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("设备型号", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("Android 版本", "Android ${android.os.Build.VERSION.RELEASE}（API ${android.os.Build.VERSION.SDK_INT}）")
            HorizontalDivider(color = Color(0xFFE9EDF2))
            DeviceInfoRow("系统指纹", android.os.Build.FINGERPRINT)
        }
    }
}

@Composable
private fun DeviceInfoRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        Text(value, color = Ink, fontSize = 13.sp)
    }
}

@Composable
private fun ComponentInfoCard(component: CarrierComponent) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(component.title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp)
                Spacer(Modifier.weight(1f))
                Text(component.carrier, color = Blue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(component.packageName, color = Muted, fontSize = 11.sp)
            Text("适用设备：${component.brands}", color = Color(0xFF46566B), fontSize = 12.sp)
            Text(component.verification, color = if (component.verified) Color(0xFF16865B) else Color(0xFFB87524), fontSize = 11.sp)
        }
    }
}

@Composable
private fun SelectableComponentCard(component: CarrierComponent, selected: Boolean, onChecked: (Boolean) -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFFF0F4FF) else Color.White), elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = selected, onCheckedChange = onChecked, colors = CheckboxDefaults.colors(checkedColor = Blue))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(component.title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(component.carrier, color = Blue, fontSize = 10.sp)
                }
                Text(component.packageName, color = Muted, fontSize = 10.sp)
                Text("${component.brands} · ${component.verification}", color = if (component.verified) Color(0xFF16865B) else Color(0xFFB87524), fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun ResultReportCard(report: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = if (report.contains("失败")) Color(0xFFFFF0EF) else Color(0xFFEAF7EF))) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("删除操作结果", color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(report, color = Color(0xFF3E4D60), fontSize = 12.sp, lineHeight = 18.sp)
            val context = LocalContext.current
            OutlinedButton(onClick = { copyText(context, report) }, modifier = Modifier.fillMaxWidth()) { Text("复制操作结果") }
        }
    }
}

@Composable
private fun ExpandableDetails(title: String, content: @Composable ColumnScope.() -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "收起：$title" else title) }
            if (expanded) content()
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String, containerColor: Color = Color.White) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = containerColor), elevation = CardDefaults.cardElevation(1.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 14.sp)
            Text(body, color = Color(0xFF596777), fontSize = 13.sp, lineHeight = 20.sp)
        }
    }
}

private fun inspectCarrierComponents(shell: ShizukuShellClient): String = shell.execute("pm list packages --user 0")

private fun parseInstalledPackages(output: String): Set<String> = output.lineSequence()
    .map { it.trim() }
    .filter { it.startsWith("package:") }
    .map { it.removePrefix("package:").trim() }
    .filter { pkg -> CARRIER_COMPONENTS.any { it.packageName == pkg } }
    .toSet()

private fun uninstallCarrierComponents(shell: ShizukuShellClient, targets: List<String>): String {
    val allowed = targets.filter { pkg -> CARRIER_COMPONENTS.any { it.packageName == pkg } }.distinct()
    if (allowed.isEmpty()) return "没有选择有效的目标组件。"
    val commands = allowed.joinToString("\n") { pkg ->
        "echo 'TARGET:$pkg'; if pm list packages --user 0 | grep -Fx 'package:$pkg' >/dev/null; then pm uninstall -k --user 0 '$pkg'; else echo 'SKIP:当前用户未安装'; fi"
    }
    val raw = shell.execute(commands)
    val verify = shell.execute("pm list packages --user 0")
    val remaining = allowed.filter { pkg -> verify.lineSequence().any { it.trim() == "package:$pkg" } }
    val removed = allowed - remaining.toSet()
    return buildString {
        append("本次选择：${allowed.size} 项\n")
        append("已从当前用户卸载：${removed.size} 项\n")
        removed.forEach { append("✓ $it\n") }
        if (remaining.isNotEmpty()) {
            append("\n未能卸载或仍然存在：${remaining.size} 项\n")
            remaining.forEach { append("✕ $it\n") }
        }
        append("\n系统返回：\n$raw")
        append("\n\n提示：卸载仅作用于当前用户空间，系统分区中的原始 APK 通常仍保留。")
        append("\n__REMAINING__\n")
        remaining.forEach { append("REMAINING|$it\n") }
    }
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText("净鉴", text))
    Toast.makeText(context, "已复制", Toast.LENGTH_SHORT).show()
}

private fun openUrl(context: Context, url: String) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (_: ActivityNotFoundException) { Toast.makeText(context, "未找到可打开链接的浏览器", Toast.LENGTH_LONG).show() }
    catch (_: Exception) { Toast.makeText(context, "无法打开链接", Toast.LENGTH_LONG).show() }
}

private fun openShizuku(context: Context) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
    if (launchIntent != null) {
        try { context.startActivity(launchIntent) } catch (_: Exception) { openUrl(context, SHIZUKU_URL) }
    } else openUrl(context, SHIZUKU_URL)
}

# 净鉴 1.3.0

- 应用名称：净鉴
- Application ID：`com.akiyo.cleanguard`
- 版本：`1.3.0`（versionCode 4）
- 技术：Kotlin + Jetpack Compose + Shizuku UserService
- minSdk：26；compileSdk / targetSdk：35
- 默认离线；Manifest 不声明 INTERNET 权限或普通运行时权限；不包含广告或统计 SDK。

## 1.3.0 更新内容

- 参考 KernelSU 首页布局，将 Shizuku 授权状态卡片置于首页顶部；未授权时显示红色状态，并在下方展开完整授权教程。
- 首页显示净鉴版本、设备型号、Android 版本和系统指纹。
- 首页保留 System Helper 的说明，并补充建议卸载的隐私保护原因和卸载影响提示。
- 欢迎提示改为每次启动应用时显示，不再将“已显示欢迎提示”写入偏好设置。
- 最近一次检测记录改为保存在本地 SharedPreferences，重新打开应用后仍可在“检测”和“操作”页面查看；首页不展示检测结果。
- 移除“系统更新后复检”功能，保留统一的“检测结论”卡片。
- 卸载成功时提示“已完成卸载！”，当前用户未安装目标组件时提示“没有找到System Helper，无需卸载哦！”。
- 合并个人信息、权限收集说明和使用规范，改用更通俗的说明。
- 统一卡片圆角、间距和颜色层级，增加柔和的状态色。

## 构建

1. 在 Android SDK Manager 中安装 Android SDK Platform 35 和 Android SDK Build-Tools 35.x。
2. 使用 JDK 17。
3. Windows 可运行项目根目录的 `build-apk.bat`；GitHub Actions 工作流也可在云端构建 Debug APK。
4. APK 输出位置：`app/build/outputs/apk/debug/app-debug.apk`。

## 功能与限制

- 通过 Shizuku UserService（AIDL Binder）执行检测和用户级卸载；未获得授权时不会执行 Shell 命令。
- System Helper（`com.mobiletools.systemhelper`）专项检查：当前用户安装状态、包记录、系统 APK 路径、权限信息节选及相关进程。
- `pm uninstall --user 0` 只对当前用户卸载，不会删除系统分区 APK；系统更新或恢复出厂设置后可能恢复。
- 检测记录保存在本机应用数据中；卸载净鉴会清除这些本地数据。
- 无线调试配对码由 Android / Shizuku 处理，净鉴不读取或保存配对码。
- 检测范围以 Android User 0 为主，不代表覆盖设备上的所有用户或工作资料。
- 权限声明不等于恶意行为证据；不同厂商、机型和系统版本的组件行为可能不同，检测结论仅供参考。
- 手动 Shell 命令功能权限较高，仅执行你理解且确认安全的命令。

## 当前验证状态

已完成源码静态检查与版本信息核对。本制作环境没有 Android SDK，尚未完成 Gradle 编译和真机验证；请以 GitHub Actions 构建结果及安装后的实际测试为准。

## 1.3.2
- Shizuku 授权教程默认收起，按需展开。
- 移除“设备隐私概览”，将 System Helper 说明移动到首页并默认收起，增加建议阅读提示。
- 将版本、设备型号、Android 版本和系统指纹整合为统一设备信息卡片。
- 请求系统优先采用设备支持的最高刷新率；最终刷新率仍受系统省电、温控和显示设置策略控制。
- APK 使用固定签名密钥。GitHub Actions 需要配置 `SIGNING_KEYSTORE_BASE64`、`SIGNING_STORE_PASSWORD`、`SIGNING_KEY_PASSWORD` 三个仓库 Secrets；构建流程会严格比较 keystore 与 APK 的 SHA-256 证书指纹，校验失败不会上传 APK。

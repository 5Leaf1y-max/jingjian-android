# 净鉴 1.4.1

- 应用名称：净鉴
- Application ID：`com.akiyo.cleanguard`
- 版本：`1.4.1`（versionCode 8）
- 技术：Kotlin + Jetpack Compose + Shizuku
- minSdk：26；compileSdk / targetSdk：35
- 当前版本未声明 INTERNET 权限；检测与卸载流程在本机执行。

## 1.4.1 更新内容

- 以 1.3.2 工程为基础，整合 1.4.0 的运营商组件检测与管理界面。
- 优化首页、检测、删除和关于页面的信息层级与卡片样式。
- 检测与删除操作结果分离：检测信息留在检测页面，卸载结果只显示在删除页面；首页不展示历史记录。
- 扩展精确包名识别清单，并区分公开资料记录与实机验证状态；未验证项目默认不选中。
- 排除小米厂商安全组件 `com.miui.guardprovider`，不把厂商安全组件当作运营商卸载目标。
- 关于页面增加隐私政策与个人信息保护说明，以及作者联系邮箱 `yeqiuyi524@gmail.com`。
- 保留 Shizuku 授权流程、固定签名配置与最高支持刷新率请求。

## 运营商组件清单说明

清单仅使用明确包名精确匹配，不使用模糊关键词批量卸载。System Helper、OPPO 自注册与 RegService 有公开实机验证记录；小米及 vivo 候选项目会标记为未由本项目实机验证，并默认不选中。设备型号、系统版本和地区可能影响组件是否存在。识别到组件不等于认定其恶意，卸载前请核对风险。

## 构建

- 使用 JDK 17、Android SDK Platform 35、Build Tools 35.0.0 和 Gradle 8.9。
- GitHub Actions 从仓库根目录的 `jingjian-android-1.4.1-source.zip` 解压构建。
- Actions 从仓库 Secrets 读取 `SIGNING_KEYSTORE_BASE64`、`SIGNING_STORE_PASSWORD`、`SIGNING_KEY_PASSWORD`。
- 工作流强制校验签名证书 SHA-256：`17E6078233474E5AD6612182485627A8582E9454519ED43AB1E9AEA0D7D69708`。
- APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 隐私与限制

- 设备信息、扫描结果和卸载结果仅用于本机展示及操作流程。
- 当前版本未集成广告或统计 SDK；未声明 INTERNET 权限。
- Shizuku 授权由用户主动确认；卸载操作仅针对当前用户空间，不会删除系统分区原始 APK。
- 本地制作环境未完成 Android SDK / Gradle 编译与真机性能测试；最终构建以 GitHub Actions 结果为准。系统省电、温控与显示策略可能影响实际刷新率，应用请求最高支持刷新率不等于保证固定帧率。

package com.akiyo.cleanguard

import android.os.Parcel
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

/** Runs inside the Shizuku-managed process (normally Android shell UID 2000). */
class ShellUserService : IShizukuShellService.Stub() {
    override fun execute(command: String): String {
        if (command.isBlank()) return "命令不能为空"
        if (command.length > 8_192) return "命令过长，已拒绝执行"

        return try {
            val process = ProcessBuilder("sh", "-c", command).start()
            val stdout = ByteArrayOutputStream()
            val stderr = ByteArrayOutputStream()
            val outThread = Thread { copyLimited(process.inputStream, stdout) }
            val errThread = Thread { copyLimited(process.errorStream, stderr) }
            outThread.start()
            errThread.start()

            if (!process.waitFor(25, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                outThread.join(1_000)
                errThread.join(1_000)
                return "执行超时（25 秒），进程已终止。\n" + stdout.toString("UTF-8") + stderr.toString("UTF-8")
            }
            outThread.join(1_000)
            errThread.join(1_000)
            buildString {
                val out = stdout.toString("UTF-8").trimEnd()
                val err = stderr.toString("UTF-8").trimEnd()
                if (out.isNotEmpty()) append(out)
                if (err.isNotEmpty()) {
                    if (isNotEmpty()) append('\n')
                    append("错误输出：\n").append(err)
                }
                if (isEmpty()) append("命令已执行，无输出")
                append("\n退出码：").append(process.exitValue())
            }
        } catch (e: Exception) {
            "执行失败：${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun copyLimited(input: InputStream, output: ByteArrayOutputStream) {
        input.use { stream ->
            val buffer = ByteArray(4_096)
            var total = 0
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                val allowed = minOf(count, 64 * 1_024 - total)
                if (allowed > 0) output.write(buffer, 0, allowed)
                total += allowed
                // Continue draining after the output cap so the child cannot block on a full pipe.
            }
        }
    }

    @Suppress("unused")
    fun destroy() {
        System.exit(0)
    }

    override fun onTransact(code: Int, data: Parcel, reply: Parcel?, flags: Int): Boolean {
        if (code == 16777115) {
            destroy()
            return true
        }
        return super.onTransact(code, data, reply, flags)
    }
}

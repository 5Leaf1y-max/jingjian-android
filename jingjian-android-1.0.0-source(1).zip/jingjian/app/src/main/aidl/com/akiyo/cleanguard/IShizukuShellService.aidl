package com.akiyo.cleanguard;

interface IShizukuShellService {
    String execute(String command);
}
